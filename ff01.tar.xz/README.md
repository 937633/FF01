# FFmpeg TUI

一个用 Python 3 + [Textual](https://textual.textualize.io/) 构建的 FFmpeg 终端界面。
不用记复杂的命令行参数，就可以在一个界面里管理媒体文件、查看媒体结构、转码、合流和分流，
并直接浏览当前 FFmpeg 安装支持的编解码器、滤镜、容器格式与协议。

![主界面](docs/main.png)

## 功能

| 功能 | 说明 |
| --- | --- |
| 启动环境检查 | 启动时自动执行 `ffmpeg -version` / `ffprobe -version`，在标题栏显示版本；缺少工具时给出安装提示 |
| 文件列表 | 按 `a` 添加文件、目录或通配符；按 `d` 从列表移除；支持清空列表。移除列表项不会删除磁盘文件 |
| 媒体结构分析 | 通过 `ffprobe -show_format -show_streams -show_chapters` 展示容器、时长、码率、视频/音频/字幕流、章节、标签和原始 JSON |
| 转码 | 选择视频/音频编码器、CRF、预设、缩放、音频码率、字幕复制和输出路径；实时显示进度、速度、FPS 和码率 |
| 合流 | 从一个文件取画面、从另一个文件取声音，也可复制字幕；默认流复制，可选重新编码 |
| 分流 | 按类型提取视频/音频/字幕，或把每一个流分别提取为独立文件；流复制不损失画质 |
| 能力浏览 | 查看当前 FFmpeg 支持的编码器、解码器、滤镜、容器格式、协议和硬件加速接口，支持搜索与刷新 |
| 任务控制 | 转码/合流/分流在后台运行，可实时查看进度并取消；失败时显示 FFmpeg 错误详情 |
| 安全默认值 | 默认不覆盖已有文件；点击按钮或使用快捷键都能操作；命令通过参数列表传给子进程，不经过 shell |

> 截图中的中文字体使用 Noto Sans Mono CJK 渲染。实际界面会使用你的终端字体，只要终端支持中文即可正常显示。

### 截图

| 转码 | FFmpeg 能力浏览 |
| --- | --- |
| ![转码](docs/transcode.png) | ![能力](docs/capabilities.png) |

## 环境要求

- Python **3.10+**
- FFmpeg，且 `ffmpeg` 与 `ffprobe` 都在 `PATH` 中
- 支持 UTF-8 的终端（建议使用等宽中文字体）

安装 FFmpeg：

```bash
# Ubuntu / Debian
sudo apt install ffmpeg

# macOS
brew install ffmpeg

# Windows
winget install Gyan.FFmpeg
```

## 安装与启动

### 一键安装（推荐）

```bash
./setup.sh
./run.sh
```

`setup.sh` 会在项目目录创建 `.venv` 并安装依赖。之后每次运行只需要 `./run.sh`。

### 手动安装

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt

python3 -m ffmpeg_tui
```

也可以安装为命令：

```bash
pip install -e .
ffmpeg-tui
```

### 启动时预加载文件

```bash
./run.sh /path/to/video.mkv /path/to/audio.m4a
./run.sh ~/Videos/
```

目录中的常见媒体文件会被自动加入列表，所有文件会在后台依次分析。

## 快捷键

| 按键 | 功能 |
| --- | --- |
| `a` | 添加文件 / 目录 / 通配符 |
| `d` | 从列表移除当前文件 |
| `Enter` / `i` | 查看完整媒体结构 |
| `t` | 转码 |
| `m` | 合流 |
| `s` | 分流 / 提取流 |
| `c` | 查看 FFmpeg 能力 |
| `r` | 重新分析当前文件 |
| `?` / `F1` | 帮助 |
| `q` | 退出 |

在对话框中：

| 按键 | 功能 |
| --- | --- |
| `Tab` / `Shift+Tab` | 在字段之间移动 |
| `↑` / `↓` | 选择下拉项或移动列表光标 |
| `Ctrl+S` | 提交转码 / 合流 / 分流表单 |
| `/` | 在能力页聚焦搜索框 |
| `Esc` / `q` | 关闭对话框；任务运行时请求取消 |

## 操作说明

### 添加文件

在添加对话框中可以输入：

- 单个文件：`~/Videos/movie.mkv`
- 目录：`/data/media/`（会收集其中扩展名已知的媒体文件）
- 通配符：`/data/media/*.mp4`
- 环境变量：`$HOME/Videos/movie.mkv`

路径支持 `~`、环境变量和 `*` / `?` / `[]` 通配符。一次最多添加 500 个文件。

### 分析媒体结构

选中文件后，右侧会显示摘要。按 `Enter` 或 `i` 打开完整分析窗口，包含：

- 概览：容器、时长、大小、总码率、媒体流
- 流详情：编码参数、分辨率、帧率、像素格式、采样率、声道、码率、语言、标签、disposition
- 章节和元数据
- 原始 ffprobe JSON（只读，支持搜索/选择）

### 转码

进入 `t` 后填写表单：

- **输出文件**：支持 `~` 和相对路径；扩展名决定容器格式
- **视频编码**：流复制、libx264、libx265、VP9、AV1、NVENC、VA-API 等
- **质量 CRF**：0–63；x264/x265 常用 18–28
- **编码预设**：`ultrafast` 到 `veryslow`
- **缩放**：例如 `1280:-2`，留空则保持原分辨率
- **音频编码/码率**：流复制、AAC、MP3、Opus、FLAC 等
- **复制字幕流**：仅在目标容器支持对应字幕编码时勾选
- **覆盖已有输出文件**：默认关闭

任务开始后会显示进度页。任务执行中按 `Esc` 或点击“取消任务”会终止 FFmpeg 进程。

### 合流

把一个文件的画面和另一个文件的声音合成一个新文件：

- 画面源：列表中含视频流的文件
- 声音源：列表中含音频流的不同文件
- 处理方式：流复制（快、无损）或重新编码为 H.264 + AAC
- 可选复制画面源中的字幕、`-shortest`、覆盖已有文件

合流前需要等待文件分析完成。状态栏会显示“分析中…”直到所有文件可读。

### 分流

把一个媒体文件拆开：

- **按类型提取**：输出视频、音频、字幕各一个文件。视频/字幕使用 Matroska，音频优先使用对应编码的扩展名（单个 AAC → `.m4a`，MP3 → `.mp3` 等；多个混合音频流 → `.mka`）
- **每个流单独提取**：每个视频/音频/字幕流生成一个独立文件

分流默认使用 `-c copy`，速度快且不损失画质。所有输出文件名会包含流索引和编码名。

### 查看 FFmpeg 能力

按 `c` 打开能力浏览器，可切换：

- 编码器（数量取决于当前安装）
- 解码器
- 滤镜
- 容器格式
- 协议
- 硬件加速接口

表格显示名称、方向/类型和说明。输入关键字可以筛选，按 `r` 重新读取当前 FFmpeg 的能力。

## 命令行模式

TUI 之外也提供两个无交互命令，便于脚本或排查环境：

```bash
# 检查 ffmpeg / ffprobe 路径、版本与可用状态
./run.sh --check

# JSON 输出
./run.sh --check --json

# 分析一个媒体文件并输出摘要
./run.sh --probe movie.mkv

# 输出完整 ffprobe JSON
./run.sh --probe movie.mkv --json
```

`--check` 在工具就绪时返回 `0`，否则返回 `2`。

## 项目结构

```text
ffmpeg_tui/
├── app.py                 # Textual 应用、主界面、文件列表、任务调度
├── app.tcss               # 界面样式
├── backend.py             # FFmpeg 发现、ffprobe、能力解析、命令构建、任务执行
├── render.py              # Rich 渲染：概览、流详情、元数据
├── cli.py                 # --check / --probe / 启动 TUI
└── screens/
    ├── add_files.py       # 添加文件
    ├── analysis.py        # 媒体结构
    ├── capabilities.py    # 编解码器/滤镜浏览器
    ├── confirm.py         # 确认与消息对话框
    ├── help.py            # 帮助
    ├── job.py             # 带进度和取消的任务页
    ├── mux.py             # 合流
    ├── split.py           # 分流
    └── transcode.py       # 转码
```

### 实现要点

- FFmpeg 进程通过 `subprocess.Popen(argv)` 执行，不拼接 shell 命令；文件路径和参数不会被 shell 解释。
- 转码进度来自 `-progress pipe:1` 的键值流，任务线程读取 `out_time_us`、`speed`、`fps`、`bitrate` 等字段。
- ffprobe 在后台线程中串行执行，不阻塞界面；每个文件只分析一次并缓存。
- 所有输出在启动前检查，默认使用 `-n` 拒绝覆盖；勾选覆盖后才使用 `-y`。
- 取消任务时先 `SIGTERM`，超时后 `SIGKILL`。
- 能力列表来自固定参数的 `ffmpeg -encoders` / `-decoders` / `-filters` / `-formats` / `-protocols` / `-hwaccels`，解析失败只影响对应分类。

## 测试

```bash
.venv/bin/pip install pytest
.venv/bin/python -m pytest
```

测试会覆盖：

- 版本与能力解析
- ffprobe 元数据
- 路径、目录、通配符展开
- 转码、合流、分流命令构建与真实执行
- 输出覆盖保护、失败任务、取消任务
- Textual 界面启动、自动分析、添加/移除、各对话框、UI 内转码与分流、FFmpeg 缺失提示

## 已知限制

- 只处理本地文件，不支持网络 URL 作为输入。
- 同一时间只运行一个 FFmpeg 任务。
- 文件列表仅在当前会话中有效，不会持久化到磁盘。
- 转码表单提供常用编码器，不列出 FFmpeg 的全部编码器；完整列表可在能力页查看。
- 硬件编码器需要对应驱动和硬件支持，否则 FFmpeg 会在任务页报错。
- “复制字幕”是否可用取决于目标容器与字幕编码；失败时请取消勾选或改用 Matroska 输出。
- 不支持播放预览；这是面向处理流程的 TUI，而不是播放器。

## License

MIT
