"""Modal progress screen for ffmpeg jobs."""

from __future__ import annotations

import contextlib
import threading

from rich.text import Text
from textual import on, work
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, ProgressBar, RichLog, Static

from ..backend import (
    JobPlan,
    JobProgress,
    JobResult,
    format_duration,
    run_plan,
)


class JobScreen(ModalScreen[JobResult]):
    BINDINGS = [
        ("escape", "cancel_or_close", "取消"),
        ("q", "cancel_or_close", "取消"),
    ]

    def __init__(self, plan: JobPlan) -> None:
        super().__init__()
        self.plan = plan
        self.cancel_event = threading.Event()
        self.result: JobResult | None = None
        self.running = True
        self._cancel_requested = False

    def compose(self) -> ComposeResult:
        total = 100.0 if self.plan.total_duration else None
        with Vertical(classes="dialog job-dialog"):
            with Horizontal(classes="dialog-titlebar"):
                yield Static(self.plan.title, classes="dialog-title")
            yield Static(self.plan.note, classes="dialog-subtitle")
            yield Static("准备中…", id="job-step", classes="job-step")
            yield ProgressBar(
                total=total,
                show_eta=True,
                id="job-progress",
                classes="job-progress",
            )
            yield Static("", id="job-stats", classes="job-stats")
            yield RichLog(
                id="job-log",
                max_lines=200,
                wrap=True,
                markup=False,
                min_width=20,
                classes="job-log",
            )
            with Horizontal(classes="form-actions"):
                yield Button("取消任务", id="job-cancel", variant="error")
                yield Button("关闭", id="job-close", variant="primary", classes="hidden")

    def on_mount(self) -> None:
        log = self.query_one("#job-log", RichLog)
        log.write(Text(self.plan.note, style="dim"))
        for step in self.plan.steps:
            log.write(Text(f"$ {step.command_text}", style="dim"))
        self._run_job()

    def on_unmount(self) -> None:
        if self.running:
            self.cancel_event.set()

    @work(thread=True, group="ffmpeg-job", exclusive=True)
    def _run_job(self) -> None:
        result = run_plan(
            self.plan,
            on_progress=self._thread_progress,
            cancel_event=self.cancel_event,
        )
        with contextlib.suppress(RuntimeError):
            self.app.call_from_thread(self._apply_result, result)

    def _thread_progress(self, progress: JobProgress) -> None:
        with contextlib.suppress(RuntimeError):
            self.app.call_from_thread(self._apply_progress, progress)

    def _apply_progress(self, progress: JobProgress) -> None:
        if not self.is_mounted:
            return
        self.query_one("#job-step", Static).update(self._step_text(progress))
        bar = self.query_one("#job-progress", ProgressBar)
        if progress.overall_percent is not None and bar.total is not None:
            bar.update(progress=progress.overall_percent)
        parts: list[str] = []
        if progress.out_time is not None:
            step = next(
                (s for s in self.plan.steps if s.label == progress.step_label),
                None,
            )
            if step and step.duration:
                parts.append(
                    f"{format_duration(progress.out_time)} / {format_duration(step.duration)}"
                )
            else:
                parts.append(format_duration(progress.out_time))
        for label, value in (
            ("speed", progress.speed),
            ("fps", progress.fps),
            ("bitrate", progress.bitrate),
            ("frame", progress.frame),
        ):
            if value:
                parts.append(f"{label} {value}")
        if progress.message:
            parts.append(progress.message)
        self.query_one("#job-stats", Static).update("  ·  ".join(parts))

    def _step_text(self, progress: JobProgress) -> Text:
        text = Text()
        text.append(f"[{progress.step_index + 1}/{progress.step_count}] ", style="dim")
        text.append(progress.step_label, style="bold")
        return text

    def _apply_result(self, result: JobResult) -> None:
        if not self.is_mounted:
            return
        self.running = False
        self.result = result
        cancel_button = self.query_one("#job-cancel", Button)
        close_button = self.query_one("#job-close", Button)
        cancel_button.display = False
        close_button.remove_class("hidden")
        close_button.focus()
        bar = self.query_one("#job-progress", ProgressBar)
        step = self.query_one("#job-step", Static)
        stats = self.query_one("#job-stats", Static)
        log = self.query_one("#job-log", RichLog)

        if result.cancelled:
            step.update(Text("任务已取消", style="bold yellow"))
            stats.update("FFmpeg 进程已终止")
            log.write(Text("已取消。", style="yellow"))
        elif result.ok:
            if bar.total is not None:
                bar.update(progress=100)
            step.update(Text("任务完成", style="bold green"))
            stats.update(
                f"输出：{', '.join(str(path) for path in result.outputs)}"
                if result.outputs
                else "任务完成"
            )
            log.write(Text("完成。", style="green"))
            for path in result.outputs:
                log.write(Text(str(path), style="bold green"))
        else:
            step.update(Text("任务失败", style="bold red"))
            stats.update(result.error or "FFmpeg 执行失败")
            log.write(Text(result.error or "FFmpeg 执行失败", style="bold red"))
            if result.log:
                recent = "\n".join(result.log.splitlines()[-20:])
                log.write(Text(recent, style="red"))

    @on(Button.Pressed, "#job-cancel")
    def _cancel_pressed(self) -> None:
        self._request_cancel()

    @on(Button.Pressed, "#job-close")
    def _close_pressed(self) -> None:
        self.dismiss(self.result)

    def action_cancel_or_close(self) -> None:
        if self.running:
            self._request_cancel()
        else:
            self.dismiss(self.result)

    def _request_cancel(self) -> None:
        if not self.running or self._cancel_requested:
            return
        self._cancel_requested = True
        self.cancel_event.set()
        self.query_one("#job-cancel", Button).disabled = True
        self.query_one("#job-step", Static).update(Text("正在取消，请稍候…", style="yellow"))
