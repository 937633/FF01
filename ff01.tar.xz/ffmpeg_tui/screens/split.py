"""Split/extract streams from a media file."""

from __future__ import annotations

from pathlib import Path

from rich.text import Text
from textual import on
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.widgets import Button, Checkbox, Input, Label, Select, Static

from ..backend import (
    FFmpegError,
    FFmpegTools,
    JobPlan,
    MediaInfo,
    build_split_plan,
    format_bitrate,
    unique_output_dir,
)
from .common import DialogScreen


class SplitScreen(DialogScreen[JobPlan]):
    BINDINGS = [
        ("escape", "cancel", "取消"),
        ("ctrl+s", "submit", "开始分流"),
    ]

    def __init__(self, tools: FFmpegTools, info: MediaInfo) -> None:
        super().__init__()
        self.tools = tools
        self.info = info
        self.default_dir = unique_output_dir(info.path, suffix="_streams")

    def compose(self) -> ComposeResult:
        with Vertical(classes="dialog form-dialog"):
            with Horizontal(classes="dialog-titlebar"):
                yield Static("分流 / 提取流", classes="dialog-title")
                yield Button("关闭", id="close", classes="close-button")
            yield Static(
                f"{self.info.path.name}  ·  {self.info.count_text}",
                classes="dialog-subtitle",
            )

            with VerticalScroll(classes="form-body"):
                with Horizontal(classes="field-row"):
                    yield Label("输出目录", classes="field-label")
                    yield Input(
                        value=str(self.default_dir),
                        id="output-dir",
                        classes="field-input",
                    )
                with Horizontal(classes="field-row"):
                    yield Label("分流方式", classes="field-label")
                    yield Select(
                        [
                            ("按类型提取（视频 / 音频 / 字幕各一个文件）", "type"),
                            ("每个流单独提取（逐流生成文件）", "stream"),
                        ],
                        value="type",
                        allow_blank=False,
                        id="split-mode",
                        classes="field-input",
                    )

                yield Static(self._stream_summary(), id="split-summary", classes="source-summary")

                with Horizontal(classes="checkbox-row"):
                    yield Checkbox("覆盖目录中已有的同名文件", id="overwrite")

                yield Static(
                    "流复制模式不会重新编码，速度很快，也不会损失画质。",
                    classes="dialog-hint",
                )
                yield Static(
                    "Tab 切换字段  ·  ↑↓ 选择下拉项  ·  Ctrl+S 开始",
                    classes="dialog-hint",
                )
                yield Static("", id="form-error", classes="form-error")

            with Horizontal(classes="form-actions"):
                yield Button("开始分流", id="submit", variant="primary")
                yield Button("取消", id="cancel")

    def _stream_summary(self) -> Text:
        text = Text()
        text.append("可提取的流\n", style="bold")
        for stream in self.info.streams:
            if stream.codec_type not in {"video", "audio", "subtitle"}:
                continue
            style = {
                "video": "cyan",
                "audio": "green",
                "subtitle": "yellow",
            }.get(stream.codec_type, "white")
            text.append(f"  #{stream.index}  ", style="dim")
            text.append(f"{stream.type_label}  ", style=style)
            text.append(stream.codec_name, style=f"bold {style}")
            text.append(f"  {stream.summary}", style="dim")
            if stream.bit_rate:
                text.append(f"  {format_bitrate(stream.bit_rate)}", style="dim")
            text.append("\n")
        if not any(
            stream.codec_type in {"video", "audio", "subtitle"} for stream in self.info.streams
        ):
            text.append("没有可提取的媒体流", style="yellow")
        return text

    @on(Button.Pressed, "#close")
    def _close_pressed(self) -> None:
        self.dismiss(None)

    @on(Button.Pressed, "#cancel")
    def _cancel_pressed(self) -> None:
        self.dismiss(None)

    @on(Button.Pressed, "#submit")
    def _submit_pressed(self) -> None:
        self.action_submit()

    def action_submit(self) -> None:
        self.clear_error()
        try:
            directory_text = self.query_one("#output-dir", Input).value.strip()
            if not directory_text:
                raise FFmpegError("请输入输出目录")
            output_dir = Path(directory_text).expanduser()
            if not output_dir.is_absolute():
                output_dir = (Path.cwd() / output_dir).resolve()
            mode = str(self.query_one("#split-mode", Select).value)
            overwrite = self.query_one("#overwrite", Checkbox).value
            plan = build_split_plan(
                self.tools,
                self.info,
                output_dir=output_dir,
                mode=mode,
                overwrite=overwrite,
            )
        except (FFmpegError, OSError) as exc:
            self.show_error(str(exc))
            return
        self.dismiss(plan)
