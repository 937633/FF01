"""Textual screens for FFmpeg TUI."""
