"""Help screen."""

from __future__ import annotations

from rich import box
from rich.console import Group
from rich.table import Table
from rich.text import Text
from textual import on
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.widgets import Button, Static

from ..backend import FFmpegTools
from .common import DialogScreen


def _shortcut_table() -> Table:
    table = Table(
        box=box.SIMPLE_HEAD,
        expand=True,
        pad_edge=False,
        title="主界面快捷键",
        title_style="bold bright_cyan",
    )
    table.add_column("按键", style="bold cyan", width=12, no_wrap=True)
    table.add_column("功能")
    rows = [
        ("a", "添加文件、目录或通配符"),
        ("d", "从列表移除当前选中文件（不删除磁盘文件）"),
        ("Enter / i", "查看当前文件的完整媒体结构"),
        ("t", "转码：选择编码器、质量、缩放和输出路径"),
        ("m", "合流：从一个文件取画面，从另一个文件取声音"),
        ("s", "分流：按类型或逐流提取视频 / 音频 / 字幕"),
        ("c", "查看当前 FFmpeg 支持的编码器、解码器、滤镜等"),
        ("r", "重新分析当前文件"),
        ("?", "打开本帮助"),
        ("q", "退出程序"),
    ]
    for key, description in rows:
        table.add_row(key, description)
    return table


def _dialog_table() -> Table:
    table = Table(
        box=box.SIMPLE_HEAD,
        expand=True,
        pad_edge=False,
        title="对话框快捷键",
        title_style="bold bright_cyan",
    )
    table.add_column("按键", style="bold cyan", width=18, no_wrap=True)
    table.add_column("功能")
    for key, description in (
        ("Tab / Shift+Tab", "在表单字段间移动"),
        ("↑ / ↓", "选择下拉项，或在列表中移动"),
        ("Enter", "提交路径输入；按钮上按下则执行"),
        ("Ctrl+S", "提交转码 / 合流 / 分流表单"),
        ("/", "在 FFmpeg 能力页聚焦搜索框"),
        ("Esc / q", "关闭对话框；任务运行时请求取消"),
    ):
        table.add_row(key, description)
    return table


class HelpScreen(DialogScreen):
    BINDINGS = [
        ("escape", "cancel", "关闭"),
        ("q", "cancel", "关闭"),
    ]

    def __init__(self, tools: FFmpegTools) -> None:
        super().__init__()
        self.tools = tools

    def compose(self) -> ComposeResult:
        status = Text(
            self.tools.status_text,
            style="green" if self.tools.available else "red",
        )
        intro = Group(
            Text("FFmpeg TUI 帮助", style="bold"),
            Text(
                "本项目是一个不依赖命令行记忆的 FFmpeg 终端界面。"
                "所有处理都在本机通过 ffmpeg / ffprobe 完成。",
                style="dim",
            ),
            Text(""),
            status,
            Text(""),
            _shortcut_table(),
            _dialog_table(),
            Text("说明", style="bold bright_cyan"),
            Text(
                "· 所有对话框里的输出路径都支持 ~；相对路径以启动程序时的目录为基准。\n"
                "· 默认不会覆盖已有文件，需在表单中明确勾选“覆盖”。\n"
                "· 合流与分流默认使用流复制，不重新编码；转码则按选择重新编码。\n"
                "· 进度页可以随时取消，FFmpeg 进程会被终止。",
                style="dim",
            ),
        )
        with Vertical(classes="dialog help-dialog"):
            with Horizontal(classes="dialog-titlebar"):
                yield Static("帮助", classes="dialog-title")
                yield Button("关闭", id="close", classes="close-button")
            with VerticalScroll(classes="help-body"):
                yield Static(intro, classes="report")
            yield Static("Esc 关闭", classes="dialog-hint")

    @on(Button.Pressed, "#close")
    def _close_pressed(self) -> None:
        self.dismiss(None)
