"""Small yes/no confirmation dialog."""

from __future__ import annotations

from rich.text import Text
from textual import on
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Static


class ConfirmScreen(ModalScreen[bool]):
    BINDINGS = [
        ("escape", "no", "取消"),
        ("n", "no", "取消"),
        ("y", "yes", "确认"),
    ]

    def __init__(
        self,
        title: str,
        message: str,
        *,
        confirm_label: str = "确认",
        danger: bool = False,
    ) -> None:
        super().__init__()
        self.title = title
        self.message = message
        self.confirm_label = confirm_label
        self.danger = danger

    def compose(self) -> ComposeResult:
        with Vertical(classes="dialog confirm-dialog"):
            yield Static(self.title, classes="dialog-title")
            yield Static(self.message, classes="confirm-message")
            with Horizontal(classes="form-actions"):
                yield Button(
                    self.confirm_label,
                    id="confirm-yes",
                    variant="error" if self.danger else "primary",
                )
                yield Button("取消", id="confirm-no")

    @on(Button.Pressed, "#confirm-yes")
    def _yes_pressed(self) -> None:
        self.dismiss(True)

    @on(Button.Pressed, "#confirm-no")
    def _no_pressed(self) -> None:
        self.dismiss(False)

    def action_yes(self) -> None:
        self.dismiss(True)

    def action_no(self) -> None:
        self.dismiss(False)


class MessageScreen(ModalScreen[None]):
    """Scrollable message dialog for errors and long explanations."""

    BINDINGS = [
        ("escape", "close", "关闭"),
        ("q", "close", "关闭"),
    ]

    def __init__(self, title: str, message: str, *, style: str = "") -> None:
        super().__init__()
        self.title = title
        self.message = message
        self.style = style

    def compose(self) -> ComposeResult:
        with Vertical(classes="dialog message-dialog"):
            yield Static(self.title, classes="dialog-title")
            yield Static(
                Text(self.message, style=self.style or "none"),
                classes="message-body",
            )
            with Horizontal(classes="form-actions"):
                yield Button("关闭", id="message-close", variant="primary")

    @on(Button.Pressed, "#message-close")
    def _close_pressed(self) -> None:
        self.dismiss(None)

    def action_close(self) -> None:
        self.dismiss(None)
