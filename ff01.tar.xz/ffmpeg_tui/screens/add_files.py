"""Add files by path, directory or glob."""

from __future__ import annotations

from textual import on
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import Button, Input, Static

from ..backend import expand_media_paths
from .common import DialogScreen


class AddFilesScreen(DialogScreen):
    BINDINGS = [("escape", "cancel", "取消")]

    def compose(self) -> ComposeResult:
        with Vertical(classes="dialog add-dialog"):
            with Horizontal(classes="dialog-titlebar"):
                yield Static("添加文件", classes="dialog-title")
                yield Button("关闭", id="close", classes="close-button")
            yield Static(
                "输入文件、目录或通配符。目录会添加其中的常见媒体文件。",
                classes="dialog-subtitle",
            )
            yield Input(
                placeholder="例如  ~/Videos/movie.mkv   或   /data/media/",
                id="path-input",
            )
            yield Static(
                "支持 ~、环境变量和 * 通配符；每次可添加一个路径或目录。",
                classes="dialog-hint",
            )
            yield Static("", id="form-error", classes="form-error")
            with Horizontal(classes="form-actions"):
                yield Button("添加", id="add", variant="primary")
                yield Button("取消", id="cancel")

    def on_mount(self) -> None:
        self.query_one("#path-input", Input).focus()

    @on(Input.Submitted, "#path-input")
    def _submitted(self) -> None:
        self._add()

    @on(Button.Pressed, "#add")
    def _add_pressed(self) -> None:
        self._add()

    @on(Button.Pressed, "#cancel")
    def _cancel_pressed(self) -> None:
        self.dismiss(None)

    @on(Button.Pressed, "#close")
    def _close_pressed(self) -> None:
        self.dismiss(None)

    def _add(self) -> None:
        self.clear_error()
        raw = self.query_one("#path-input", Input).value.strip()
        try:
            paths, skipped = expand_media_paths(raw)
        except (ValueError, OSError) as exc:
            self.show_error(str(exc))
            return
        if skipped:
            self.notify("；".join(skipped), severity="warning", timeout=6)
        self.dismiss(paths)
