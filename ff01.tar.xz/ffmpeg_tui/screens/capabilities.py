"""Browse encoders, decoders, filters and other FFmpeg capabilities."""

from __future__ import annotations

import asyncio

from rich.text import Text
from textual import on
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import Button, DataTable, Input, Select, Static

from ..backend import (
    CATEGORY_DESCRIPTIONS,
    CATEGORY_LABELS,
    Capabilities,
    Capability,
    FFmpegTools,
)
from .common import DialogScreen


class CapabilitiesScreen(DialogScreen):
    BINDINGS = [
        ("escape", "cancel", "关闭"),
        ("q", "cancel", "关闭"),
        ("slash", "focus_search", "搜索"),
        ("r", "reload", "刷新"),
    ]

    def __init__(self, tools: FFmpegTools) -> None:
        super().__init__()
        self.tools = tools
        self._caps: Capabilities | None = None
        self._loading = False

    def compose(self) -> ComposeResult:
        options = [(label, key) for key, label in CATEGORY_LABELS.items()]
        with Vertical(classes="dialog capability-dialog"):
            with Horizontal(classes="dialog-titlebar"):
                yield Static("FFmpeg 能力", classes="dialog-title")
                yield Button("关闭", id="close", classes="close-button")
            yield Static(
                "查看当前安装的 FFmpeg 支持的编码器、解码器、滤镜、容器、协议与硬件加速。",
                classes="dialog-subtitle",
            )
            with Horizontal(classes="cap-toolbar"):
                yield Select(
                    options,
                    value="encoders",
                    allow_blank=False,
                    id="cap-category",
                    classes="cap-category",
                )
                yield Input(
                    placeholder="筛选名称或说明…",
                    id="cap-search",
                    classes="cap-search",
                )
                yield Button("刷新", id="cap-refresh")
            yield Static("正在读取 FFmpeg 能力…", id="cap-status", classes="cap-status")
            yield DataTable(
                id="cap-table",
                cursor_type="row",
                zebra_stripes=True,
            )
            yield Static(
                "↑↓ 选择  ·  / 搜索  ·  r 刷新  ·  Esc 关闭"
                + (
                    f"  ·  来自 FFmpeg {self.tools.ffmpeg_version}"
                    if self.tools.ffmpeg_version
                    else ""
                ),
                classes="dialog-hint",
            )

    def on_mount(self) -> None:
        table = self.query_one("#cap-table", DataTable)
        table.add_columns("名称", "方向 / 类型", "说明")
        table.focus()
        self._load()

    @on(Button.Pressed, "#close")
    def _close_pressed(self) -> None:
        self.dismiss(None)

    @on(Button.Pressed, "#cap-refresh")
    def _refresh_pressed(self) -> None:
        self._load()

    @on(Select.Changed, "#cap-category")
    def _category_changed(self) -> None:
        self._reload_table()

    @on(Input.Changed, "#cap-search")
    def _search_changed(self) -> None:
        self._reload_table()

    def action_focus_search(self) -> None:
        self.query_one("#cap-search", Input).focus()

    def action_reload(self) -> None:
        self._load()

    def _load(self) -> None:
        if self._loading:
            return
        self._loading = True
        self._caps = None
        self.query_one("#cap-status", Static).update(Text("正在读取 FFmpeg 能力…", style="yellow"))
        self.query_one("#cap-table", DataTable).clear()
        self.run_worker(self._fetch(), name="capability-loader", exclusive=True)

    async def _fetch(self) -> None:
        try:
            caps = await asyncio.to_thread(self.tools.load_capabilities)
        except Exception as exc:
            self._loading = False
            self.query_one("#cap-status", Static).update(Text(f"读取失败：{exc}", style="bold red"))
            self.notify(str(exc), title="无法读取 FFmpeg 能力", severity="error", timeout=8)
            return
        self._caps = caps
        self._loading = False
        self._reload_table()

    def _reload_table(self) -> None:
        table = self.query_one("#cap-table", DataTable)
        status = self.query_one("#cap-status", Static)
        if self._caps is None:
            return
        category = self.query_one("#cap-category", Select).value
        if category is Select.BLANK or category is None:
            category = "encoders"
        category = str(category)
        query = self.query_one("#cap-search", Input).value.strip().casefold()
        items = self._caps.items(category)
        filtered = [
            item
            for item in items
            if not query
            or query in item.name.casefold()
            or query in item.description.casefold()
            or query in item.group.casefold()
            or query in item.extra.casefold()
        ]
        table.clear()
        for item in filtered:
            table.add_row(
                Text(item.name, style="bold"),
                self._direction_cell(item),
                item.description,
            )
        label = CATEGORY_LABELS.get(category, category)
        description = CATEGORY_DESCRIPTIONS.get(category, "")
        error = self._caps.errors.get(category)
        if error:
            status.update(Text(f"{label}：读取失败 — {error}", style="bold red"))
        elif filtered:
            extra = f"  ·  共 {len(items)} 项" if query else ""
            status.update(f"{label}：{len(filtered)} 项{extra}  ·  {description}")
        else:
            status.update(
                Text(
                    f"{label}：没有匹配“{query}”的项目" if query else f"{label}：没有可用项目",
                    style="yellow",
                )
            )

    @staticmethod
    def _direction_cell(item: Capability) -> Text:
        if item.extra and item.group and item.extra != item.group:
            value = f"{item.group} · {item.extra}"
        else:
            value = item.group or item.extra or "—"
        style = "cyan"
        if item.group in {"音频", "音视频"}:
            style = "green"
        elif item.group in {"复用", "解复用", "输入 + 输出", "输入", "输出"}:
            style = "magenta"
        elif item.group == "硬件加速" or "硬件" in item.extra:
            style = "yellow"
        return Text(value, style=style)
