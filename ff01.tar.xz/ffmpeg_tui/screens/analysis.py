"""Media structure analysis dialog."""

from __future__ import annotations

from textual import on
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.widgets import Button, Static, TabbedContent, TabPane, TextArea

from ..backend import MediaInfo
from ..render import render_metadata, render_overview, render_streams_detail
from .common import DialogScreen


class AnalysisScreen(DialogScreen):
    BINDINGS = [
        ("escape", "cancel", "关闭"),
        ("q", "cancel", "关闭"),
    ]

    def __init__(self, info: MediaInfo) -> None:
        super().__init__()
        self.info = info

    def compose(self) -> ComposeResult:
        with Vertical(classes="dialog analysis-dialog"):
            with Horizontal(classes="dialog-titlebar"):
                yield Static(
                    f"媒体结构 · {self.info.path.name}",
                    classes="dialog-title",
                )
                yield Button("关闭", id="close", classes="close-button")
            yield Static(str(self.info.path), classes="dialog-subtitle")

            with TabbedContent(initial="tab-overview", id="analysis-tabs"):
                with (
                    TabPane("概览", id="tab-overview"),
                    VerticalScroll(classes="tab-scroll"),
                ):
                    yield Static(render_overview(self.info, compact=True), classes="report")
                with (
                    TabPane("流详情", id="tab-streams"),
                    VerticalScroll(classes="tab-scroll"),
                ):
                    yield Static(render_streams_detail(self.info), classes="report")
                with (
                    TabPane("章节与元数据", id="tab-meta"),
                    VerticalScroll(classes="tab-scroll"),
                ):
                    yield Static(render_metadata(self.info), classes="report")
                with TabPane("原始 JSON", id="tab-json"):
                    yield TextArea(
                        self.info.raw_json(),
                        language="json",
                        read_only=True,
                        show_line_numbers=True,
                        soft_wrap=False,
                        id="raw-json",
                    )

            yield Static(
                "Tab / Shift+Tab 切换标签  ·  ↑↓ PgUp PgDn 滚动  ·  Esc 关闭",
                classes="dialog-hint",
            )

    @on(Button.Pressed, "#close")
    def _close_pressed(self) -> None:
        self.dismiss(None)
