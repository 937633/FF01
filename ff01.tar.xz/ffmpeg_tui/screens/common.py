"""Shared helpers for modal screens."""

from __future__ import annotations

import contextlib
from typing import Generic, TypeVar

from rich.text import Text
from textual.css.query import NoMatches
from textual.screen import ModalScreen
from textual.widgets import Static

ScreenResultType = TypeVar("ScreenResultType")


class DialogScreen(ModalScreen[ScreenResultType], Generic[ScreenResultType]):
    """Base class with a consistent cancel/error behaviour."""

    def action_cancel(self) -> None:
        self.dismiss(None)

    def show_error(self, message: str) -> None:
        try:
            label = self.query_one("#form-error", Static)
        except NoMatches:
            self.notify(message, severity="error", timeout=6)
            return
        label.update(Text(message, style="bold red"))
        label.display = True
        with contextlib.suppress(Exception):
            label.scroll_visible()

    def clear_error(self) -> None:
        try:
            label = self.query_one("#form-error", Static)
        except NoMatches:
            return
        label.update("")
        label.display = False
