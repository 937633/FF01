"""Transcode form."""

from __future__ import annotations

import re
from pathlib import Path

from textual import on
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.widgets import Button, Checkbox, Input, Label, Select, Static

from ..backend import (
    Capabilities,
    FFmpegError,
    FFmpegTools,
    JobPlan,
    MediaInfo,
    build_transcode_plan,
    unique_output_path,
)
from .common import DialogScreen

VIDEO_CHOICES = [
    ("libx264", "H.264 · libx264"),
    ("libx265", "H.265 / HEVC · libx265"),
    ("libvpx-vp9", "VP9 · libvpx-vp9"),
    ("libaom-av1", "AV1 · libaom-av1"),
    ("libsvtav1", "AV1 · libsvtav1"),
    ("h264_nvenc", "H.264 · NVIDIA NVENC"),
    ("hevc_nvenc", "H.265 · NVIDIA NVENC"),
    ("h264_vaapi", "H.264 · VA-API"),
    ("hevc_vaapi", "H.265 · VA-API"),
]
AUDIO_CHOICES = [
    ("aac", "AAC"),
    ("libmp3lame", "MP3 · libmp3lame"),
    ("libopus", "Opus · libopus"),
    ("libvorbis", "Vorbis · libvorbis"),
    ("flac", "FLAC"),
    ("ac3", "AC-3"),
    ("pcm_s16le", "PCM 16-bit"),
]
PRESETS = [
    "ultrafast",
    "superfast",
    "veryfast",
    "faster",
    "fast",
    "medium",
    "slow",
    "slower",
    "veryslow",
]


class TranscodeScreen(DialogScreen[JobPlan]):
    BINDINGS = [
        ("escape", "cancel", "取消"),
        ("ctrl+s", "submit", "开始转码"),
    ]

    def __init__(
        self,
        tools: FFmpegTools,
        info: MediaInfo,
        capabilities: Capabilities | None = None,
    ) -> None:
        super().__init__()
        self.tools = tools
        self.info = info
        self.capabilities = capabilities
        self.has_video = bool(info.video_streams)
        self.has_audio = bool(info.audio_streams)

        available_encoders = (
            {item.name for item in capabilities.items("encoders")}
            if capabilities is not None
            else None
        )

        def filter_choices(
            choices: list[tuple[str, str]], include: list[str]
        ) -> list[tuple[str, str]]:
            if available_encoders is None:
                return [(value, label) for value, label in choices]
            return [
                (value, label)
                for value, label in choices
                if value in include or value in available_encoders
            ]

        self.video_options: list[tuple[str, str]] = [
            ("复制视频流（不重编码）", "copy"),
            ("移除视频", "none"),
        ]
        if self.has_video:
            self.video_options.extend(
                (label, value) for value, label in filter_choices(VIDEO_CHOICES, ["copy", "none"])
            )
        else:
            self.video_options = [("移除视频（源文件没有视频流）", "none")]

        self.audio_options: list[tuple[str, str]] = [
            ("复制音频流（不重编码）", "copy"),
            ("移除音频", "none"),
        ]
        if self.has_audio:
            self.audio_options.extend(
                (label, value) for value, label in filter_choices(AUDIO_CHOICES, ["copy", "none"])
            )
        else:
            self.audio_options = [("移除音频（源文件没有音频流）", "none")]

        available_video = {value for _, value in self.video_options}
        available_audio = {value for _, value in self.audio_options}
        self.default_video = (
            ("libx264" if "libx264" in available_video else "copy") if self.has_video else "none"
        )
        self.default_audio = (
            ("aac" if "aac" in available_audio else "copy") if self.has_audio else "none"
        )

        extension = ".mp4" if self.has_video else ".m4a"
        self.default_output = unique_output_path(
            info.path, suffix="_converted", extension=extension
        )

    def compose(self) -> ComposeResult:
        with Vertical(classes="dialog form-dialog"):
            with Horizontal(classes="dialog-titlebar"):
                yield Static("转码", classes="dialog-title")
                yield Button("关闭", id="close", classes="close-button")
            yield Static(
                f"{self.info.path.name}  ·  {self.info.count_text}",
                classes="dialog-subtitle",
            )

            with VerticalScroll(classes="form-body"):
                with Horizontal(classes="field-row"):
                    yield Label("输出文件", classes="field-label")
                    yield Input(
                        value=str(self.default_output),
                        id="output",
                        classes="field-input",
                    )

                with Horizontal(classes="field-row"):
                    yield Label("视频编码", classes="field-label")
                    yield Select(
                        self.video_options,
                        value=self.default_video,
                        allow_blank=False,
                        id="video-codec",
                        classes="field-input",
                    )
                with Horizontal(classes="field-row"):
                    yield Label("质量 CRF", classes="field-label")
                    yield Input(
                        value="23" if self.default_video not in {"copy", "none"} else "",
                        placeholder="0–63；x264/x265 常用 18–28",
                        id="crf",
                        classes="field-input",
                    )
                with Horizontal(classes="field-row"):
                    yield Label("编码预设", classes="field-label")
                    yield Select(
                        [(value, value) for value in PRESETS],
                        value="medium",
                        allow_blank=False,
                        id="preset",
                        classes="field-input",
                    )
                with Horizontal(classes="field-row"):
                    yield Label("缩放", classes="field-label")
                    yield Input(
                        placeholder="留空不缩放，例如 1280:-2",
                        id="scale",
                        classes="field-input",
                    )

                with Horizontal(classes="field-row"):
                    yield Label("音频编码", classes="field-label")
                    yield Select(
                        self.audio_options,
                        value=self.default_audio,
                        allow_blank=False,
                        id="audio-codec",
                        classes="field-input",
                    )
                with Horizontal(classes="field-row"):
                    yield Label("音频码率", classes="field-label")
                    yield Input(
                        value="192k" if self.default_audio not in {"copy", "none"} else "",
                        placeholder="例如 192k；复制或无损编码时留空",
                        id="audio-bitrate",
                        classes="field-input",
                    )

                with Horizontal(classes="checkbox-row"):
                    yield Checkbox("复制字幕流（容器支持时）", id="copy-subs")
                    yield Checkbox("覆盖已有输出文件", id="overwrite")

                yield Static(
                    "Tab 切换字段  ·  ↑↓ 选择下拉项  ·  Ctrl+S 开始",
                    classes="dialog-hint",
                )
                yield Static("", id="form-error", classes="form-error")

            with Horizontal(classes="form-actions"):
                yield Button("开始转码", id="submit", variant="primary")
                yield Button("取消", id="cancel")

    def on_mount(self) -> None:
        self.query_one("#output", Input).focus()
        self._sync_video_fields()

    @on(Select.Changed, "#video-codec")
    def _video_changed(self) -> None:
        self._sync_video_fields()

    @on(Button.Pressed, "#close")
    def _close_pressed(self) -> None:
        self.dismiss(None)

    @on(Button.Pressed, "#cancel")
    def _cancel_pressed(self) -> None:
        self.dismiss(None)

    @on(Button.Pressed, "#submit")
    def _submit_pressed(self) -> None:
        self.action_submit()

    def _sync_video_fields(self) -> None:
        try:
            codec = str(self.query_one("#video-codec", Select).value)
            video_disabled = codec in {"copy", "none"}
            encode_disabled = codec == "none"
            self.query_one("#crf", Input).disabled = video_disabled
            self.query_one("#preset", Select).disabled = video_disabled
            self.query_one("#scale", Input).disabled = video_disabled
            if codec == "copy":
                self.query_one("#crf", Input).value = ""
                self.query_one("#scale", Input).value = ""
            if codec in {"none", "copy"}:
                pass
            # A disabled select still shows the previous preset, which is fine.
            self.query_one("#preset", Select).disabled = encode_disabled or video_disabled
        except Exception:
            pass

    def action_submit(self) -> None:
        self.clear_error()
        try:
            output_text = self.query_one("#output", Input).value.strip()
            if not output_text:
                raise FFmpegError("请输入输出文件路径")
            output = Path(output_text).expanduser()
            if not output.is_absolute():
                output = (Path.cwd() / output).resolve()

            video_codec = str(self.query_one("#video-codec", Select).value)
            audio_codec = str(self.query_one("#audio-codec", Select).value)
            if video_codec == "none" and audio_codec == "none":
                raise FFmpegError("视频和音频不能都被移除")

            crf_text = self.query_one("#crf", Input).value.strip()
            crf: int | None = None
            if crf_text and video_codec not in {"copy", "none"}:
                try:
                    crf = int(crf_text)
                except ValueError as exc:
                    raise FFmpegError("CRF 必须是整数") from exc
                if not 0 <= crf <= 63:
                    raise FFmpegError("CRF 应在 0–63 之间")

            preset: str | None = None
            if video_codec in {
                "libx264",
                "libx265",
                "libsvtav1",
            }:
                preset = str(self.query_one("#preset", Select).value)

            scale_text = self.query_one("#scale", Input).value.strip()
            scale = scale_text or None
            if scale:
                if video_codec == "copy":
                    raise FFmpegError("复制视频流时不能设置缩放")
                if not re.fullmatch(r"\d+:-?\d+", scale):
                    raise FFmpegError("缩放格式应为 WIDTH:HEIGHT，例如 1280:-2")

            audio_bitrate_text = self.query_one("#audio-bitrate", Input).value.strip()
            if audio_bitrate_text and not re.fullmatch(r"\d+[kKmM]?", audio_bitrate_text):
                raise FFmpegError("音频码率格式不正确，例如 192k")
            audio_bitrate = audio_bitrate_text or None

            overwrite = self.query_one("#overwrite", Checkbox).value
            copy_subs = self.query_one("#copy-subs", Checkbox).value
            plan = build_transcode_plan(
                self.tools,
                self.info,
                output_path=output,
                video_codec=video_codec,
                audio_codec=audio_codec,
                crf=crf,
                preset=preset,
                audio_bitrate=audio_bitrate,
                scale=scale,
                copy_subtitles=copy_subs,
                overwrite=overwrite,
            )
        except (FFmpegError, OSError) as exc:
            self.show_error(str(exc))
            return
        self.dismiss(plan)
