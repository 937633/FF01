"""Mux a video source and an audio source into one container."""

from __future__ import annotations

from pathlib import Path

from rich.text import Text
from textual import on
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.widgets import Button, Checkbox, Input, Label, Select, Static

from ..backend import (
    FFmpegError,
    FFmpegTools,
    JobPlan,
    MediaInfo,
    build_mux_plan,
    format_duration,
    unique_output_path,
)
from .common import DialogScreen


class MuxScreen(DialogScreen[JobPlan]):
    BINDINGS = [
        ("escape", "cancel", "取消"),
        ("ctrl+s", "submit", "开始合流"),
    ]

    def __init__(self, tools: FFmpegTools, sources: list[MediaInfo]) -> None:
        super().__init__()
        self.tools = tools
        self.sources = sources
        self.by_path = {str(info.path): info for info in sources}
        self.video_sources = [info for info in sources if info.video_streams]
        self.audio_sources = [info for info in sources if info.audio_streams]
        if not self.video_sources:
            raise FFmpegError("文件列表中没有包含视频流的文件")
        if not self.audio_sources:
            raise FFmpegError("文件列表中没有包含音频流的文件")

        self.default_video = str(self.video_sources[0].path)
        self.default_audio = next(
            (str(info.path) for info in self.audio_sources if str(info.path) != self.default_video),
            str(self.audio_sources[0].path),
        )
        self.default_output = unique_output_path(
            self.video_sources[0].path, suffix="_mux", extension=".mkv"
        )

    def compose(self) -> ComposeResult:
        video_options = [
            (
                (
                    f"{info.path.name} · {format_duration(info.duration)} · "
                    f"{info.video_streams[0].codec_name}"
                ),
                str(info.path),
            )
            for info in self.video_sources
        ]
        audio_options = [
            (
                (
                    f"{info.path.name} · {format_duration(info.duration)} · "
                    f"{info.audio_streams[0].codec_name}"
                ),
                str(info.path),
            )
            for info in self.audio_sources
        ]

        with Vertical(classes="dialog form-dialog"):
            with Horizontal(classes="dialog-titlebar"):
                yield Static("合流", classes="dialog-title")
                yield Button("关闭", id="close", classes="close-button")
            yield Static(
                "选择画面源和声音源，将它们合成为一个新文件。",
                classes="dialog-subtitle",
            )

            with VerticalScroll(classes="form-body"):
                with Horizontal(classes="field-row"):
                    yield Label("输出文件", classes="field-label")
                    yield Input(
                        value=str(self.default_output),
                        id="output",
                        classes="field-input",
                    )
                with Horizontal(classes="field-row"):
                    yield Label("画面源", classes="field-label")
                    yield Select(
                        video_options,
                        value=self.default_video,
                        allow_blank=False,
                        id="video-source",
                        classes="field-input",
                    )
                with Horizontal(classes="field-row"):
                    yield Label("声音源", classes="field-label")
                    yield Select(
                        audio_options,
                        value=self.default_audio,
                        allow_blank=False,
                        id="audio-source",
                        classes="field-input",
                    )
                with Horizontal(classes="field-row"):
                    yield Label("处理方式", classes="field-label")
                    yield Select(
                        [
                            ("流复制（快速，不重新编码）", "copy"),
                            ("重新编码（H.264 + AAC，兼容性更好）", "encode"),
                        ],
                        value="copy",
                        allow_blank=False,
                        id="mux-mode",
                        classes="field-input",
                    )

                yield Static("", id="mux-summary", classes="source-summary")

                with Horizontal(classes="checkbox-row"):
                    yield Checkbox("复制画面源中的字幕流", id="copy-subs", value=True)
                    yield Checkbox("覆盖已有输出文件", id="overwrite")
                with Horizontal(classes="checkbox-row"):
                    yield Checkbox("以较短的流为准（-shortest）", id="shortest")

                yield Static(
                    "Tab 切换字段  ·  ↑↓ 选择下拉项  ·  Ctrl+S 开始",
                    classes="dialog-hint",
                )
                yield Static("", id="form-error", classes="form-error")

            with Horizontal(classes="form-actions"):
                yield Button("开始合流", id="submit", variant="primary")
                yield Button("取消", id="cancel")

    def on_mount(self) -> None:
        self._update_summary()
        self.query_one("#output", Input).focus()

    @on(Select.Changed, "#video-source")
    def _video_source_changed(self) -> None:
        self._update_summary()

    @on(Select.Changed, "#audio-source")
    def _audio_source_changed(self) -> None:
        self._update_summary()

    def _update_summary(self) -> None:
        try:
            video = self.by_path.get(str(self.query_one("#video-source", Select).value))
            audio = self.by_path.get(str(self.query_one("#audio-source", Select).value))
        except Exception:
            return
        text = Text()
        if video:
            stream = video.video_streams[0]
            text.append("画面  ", style="bold")
            text.append(
                f"{video.path.name}  {stream.codec_name}  {stream.summary}",
                style="cyan",
            )
        if video and audio:
            text.append("\n")
        if audio:
            stream = audio.audio_streams[0]
            text.append("声音  ", style="bold")
            text.append(
                f"{audio.path.name}  {stream.codec_name}  {stream.summary}",
                style="green",
            )
        self.query_one("#mux-summary", Static).update(text)

    @on(Button.Pressed, "#close")
    def _close_pressed(self) -> None:
        self.dismiss(None)

    @on(Button.Pressed, "#cancel")
    def _cancel_pressed(self) -> None:
        self.dismiss(None)

    @on(Button.Pressed, "#submit")
    def _submit_pressed(self) -> None:
        self.action_submit()

    def action_submit(self) -> None:
        self.clear_error()
        try:
            video_value = str(self.query_one("#video-source", Select).value)
            audio_value = str(self.query_one("#audio-source", Select).value)
            video_info = self.by_path.get(video_value)
            audio_info = self.by_path.get(audio_value)
            if video_info is None or audio_info is None:
                raise FFmpegError("请选择有效的画面源和声音源")
            if video_info.path == audio_info.path:
                raise FFmpegError("画面源和声音源不能是同一个文件")

            output_text = self.query_one("#output", Input).value.strip()
            if not output_text:
                raise FFmpegError("请输入输出文件路径")
            output = Path(output_text).expanduser()
            if not output.is_absolute():
                output = (Path.cwd() / output).resolve()

            mode = str(self.query_one("#mux-mode", Select).value)
            overwrite = self.query_one("#overwrite", Checkbox).value
            copy_subs = self.query_one("#copy-subs", Checkbox).value
            shortest = self.query_one("#shortest", Checkbox).value
            plan = build_mux_plan(
                self.tools,
                video_info,
                audio_info,
                output_path=output,
                encode=mode == "encode",
                copy_subtitles=copy_subs,
                shortest=shortest,
                overwrite=overwrite,
            )
        except (FFmpegError, OSError) as exc:
            self.show_error(str(exc))
            return
        self.dismiss(plan)
