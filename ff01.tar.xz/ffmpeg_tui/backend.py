"""FFmpeg discovery, media probing, capability parsing and job execution.

This module deliberately has no UI dependencies so it can be tested on its
own and reused from the command line.
"""

from __future__ import annotations

import contextlib
import json
import os
import re
import shlex
import shutil
import subprocess
import tempfile
import threading
import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from queue import Empty, Queue
from typing import Any

# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class FFmpegError(RuntimeError):
    """Base error for all FFmpeg related failures."""


class FFmpegNotFoundError(FFmpegError):
    """Raised when ffmpeg is required but not installed."""


class FFprobeNotFoundError(FFmpegError):
    """Raised when ffprobe is required but not installed."""


class ProbeError(FFmpegError):
    """Raised when a media file cannot be probed."""


class OutputExistsError(FFmpegError):
    """Raised when an output would overwrite an existing file."""


# ---------------------------------------------------------------------------
# Small value helpers
# ---------------------------------------------------------------------------


def format_duration(seconds: float | None, *, millis: bool = False) -> str:
    """Return HH:MM:SS (or MM:SS for short durations)."""
    if seconds is None:
        return "未知"
    try:
        value = max(0.0, float(seconds))
    except (TypeError, ValueError):
        return "未知"
    total = int(value)
    hours, rem = divmod(total, 3600)
    minutes, secs = divmod(rem, 60)
    if millis:
        ms = round((value - total) * 1000)
        if ms == 1000:
            ms = 999
        if hours:
            return f"{hours:02d}:{minutes:02d}:{secs:02d}.{ms:03d}"
        return f"{minutes:02d}:{secs:02d}.{ms:03d}"
    if hours:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def format_size(size: float | None) -> str:
    if size is None:
        return "未知"
    value = float(size)
    units = ["B", "KiB", "MiB", "GiB", "TiB"]
    index = 0
    while value >= 1024 and index < len(units) - 1:
        value /= 1024
        index += 1
    if index == 0:
        return f"{int(value)} {units[index]}"
    return f"{value:.1f} {units[index]}"


def format_bitrate(bits: float | None) -> str:
    if not bits:
        return "未知"
    value = float(bits)
    if value >= 1_000_000:
        return f"{value / 1_000_000:.1f} Mb/s"
    if value >= 1_000:
        return f"{value / 1_000:.0f} kb/s"
    return f"{value:.0f} b/s"


def format_fps(value: str | float | None) -> str:
    if value is None:
        return "未知"
    if isinstance(value, str):
        try:
            if "/" in value:
                num, den = value.split("/", 1)
                value = float(num) / float(den or 1)
            else:
                value = float(value)
        except (ValueError, ZeroDivisionError):
            return value
    if abs(float(value) - round(float(value))) < 0.001:
        return f"{float(value):.0f}"
    return f"{float(value):.2f}".rstrip("0").rstrip(".")


def human_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def human_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


# ---------------------------------------------------------------------------
# FFmpeg / ffprobe discovery
# ---------------------------------------------------------------------------


_VERSION_RE = re.compile(r"^ffmpeg version\s+(\S+)", re.IGNORECASE)


@dataclass
class FFmpegTools:
    """Locations and versions of the external binaries."""

    ffmpeg_path: str | None = None
    ffprobe_path: str | None = None
    ffmpeg_version: str | None = None
    ffprobe_version: str | None = None
    ffmpeg_error: str | None = None
    ffprobe_error: str | None = None

    @classmethod
    def discover(
        cls,
        ffmpeg_bin: str = "ffmpeg",
        ffprobe_bin: str = "ffprobe",
        *,
        timeout: float = 10.0,
    ) -> FFmpegTools:
        ffmpeg_path = shutil.which(ffmpeg_bin)
        ffprobe_path = shutil.which(ffprobe_bin)

        # A common local installation layout has both binaries side by side.
        if ffmpeg_path and not ffprobe_path:
            candidate = Path(ffmpeg_path).with_name("ffprobe" + (Path(ffmpeg_path).suffix or ""))
            if candidate.is_file() and os.access(candidate, os.X_OK):
                ffprobe_path = str(candidate)

        info = cls(ffmpeg_path=ffmpeg_path, ffprobe_path=ffprobe_path)

        if ffmpeg_path:
            code, out, err = _run_capture([ffmpeg_path, "-version"], timeout)
            text = out or err
            match = _VERSION_RE.search(text or "")
            if match:
                info.ffmpeg_version = match.group(1)
            elif code != 0:
                info.ffmpeg_error = _tail(err) or "ffmpeg -version 执行失败"
        else:
            info.ffmpeg_error = "未找到 ffmpeg 可执行文件"

        if ffprobe_path:
            code, out, err = _run_capture([ffprobe_path, "-version"], timeout)
            text = out or err
            match = re.search(r"^ffprobe version\s+(\S+)", text or "", re.IGNORECASE | re.MULTILINE)
            if match:
                info.ffprobe_version = match.group(1)
            elif code != 0:
                info.ffprobe_error = _tail(err) or "ffprobe -version 执行失败"
        else:
            info.ffprobe_error = "未找到 ffprobe 可执行文件"

        return info

    @property
    def can_probe(self) -> bool:
        return bool(self.ffprobe_path)

    @property
    def can_run(self) -> bool:
        return bool(self.ffmpeg_path)

    @property
    def available(self) -> bool:
        return self.can_probe and self.can_run

    @property
    def status_text(self) -> str:
        if self.ffmpeg_path and self.ffprobe_path:
            return f"FFmpeg {self.ffmpeg_version or '?'}  ·  ffprobe {self.ffprobe_version or '?'}"
        if self.ffmpeg_path:
            return f"FFmpeg {self.ffmpeg_version or '?'}  ·  缺少 ffprobe"
        return "未检测到 FFmpeg"

    def require_ffmpeg(self) -> str:
        if not self.ffmpeg_path:
            raise FFmpegNotFoundError("未找到 ffmpeg。请先安装 FFmpeg，或设置 PATH 后重新启动。")
        return self.ffmpeg_path

    def require_ffprobe(self) -> str:
        if not self.ffprobe_path:
            raise FFprobeNotFoundError(
                "未找到 ffprobe。请安装完整的 FFmpeg 工具集，或设置 PATH 后重新启动。"
            )
        return self.ffprobe_path

    def probe(self, path: str | os.PathLike[str], *, timeout: float = 45.0) -> MediaInfo:
        ffprobe = self.require_ffprobe()
        media_path = Path(path).expanduser()
        if not media_path.exists():
            raise ProbeError(f"文件不存在：{media_path}")
        if not media_path.is_file():
            raise ProbeError(f"不是普通文件：{media_path}")

        argv = [
            ffprobe,
            "-hide_banner",
            "-v",
            "error",
            "-print_format",
            "json",
            "-show_format",
            "-show_streams",
            "-show_chapters",
            str(media_path),
        ]
        code, out, err = _run_capture(argv, timeout)
        if code != 0:
            raise ProbeError(_tail(err) or f"ffprobe 退出码 {code}")
        try:
            raw = json.loads(out or "{}")
        except json.JSONDecodeError as exc:
            raise ProbeError(f"ffprobe 返回了无法解析的 JSON：{exc}") from exc
        if not raw.get("streams") and not raw.get("format"):
            raise ProbeError(_tail(err) or "文件中没有可识别的媒体流")
        return MediaInfo(path=media_path, raw=raw)

    def load_capabilities(self, *, timeout: float = 25.0) -> Capabilities:
        ffmpeg = self.require_ffmpeg()
        commands: dict[str, tuple[list[str], Callable[[str], list[Capability]]]] = {
            "encoders": (["-encoders"], parse_encoders),
            "decoders": (["-decoders"], parse_decoders),
            "filters": (["-filters"], parse_filters),
            "formats": (["-formats"], parse_formats),
            "protocols": (["-protocols"], parse_protocols),
            "hwaccels": (["-hwaccels"], parse_hwaccels),
        }
        groups: dict[str, list[Capability]] = {}
        errors: dict[str, str] = {}
        for key, (extra, parser) in commands.items():
            code, out, err = _run_capture([ffmpeg, "-hide_banner", *extra], timeout)
            if code != 0:
                groups[key] = []
                errors[key] = _tail(err) or f"ffmpeg {' '.join(extra)} 退出码 {code}"
                continue
            try:
                groups[key] = parser(out)
            except Exception as exc:  # parsers should be defensive, but never break the UI
                groups[key] = []
                errors[key] = f"解析能力列表失败：{exc}"
        return Capabilities(
            groups=groups,
            errors=errors,
            version=self.ffmpeg_version,
            loaded_at=time.time(),
        )


def _run_capture(argv: Sequence[str], timeout: float) -> tuple[int, str, str]:
    """Run a command and return (returncode, stdout, stderr)."""
    try:
        proc = subprocess.run(
            list(argv),
            stdin=subprocess.DEVNULL,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            check=False,
        )
    except FileNotFoundError as exc:
        return 127, "", str(exc)
    except subprocess.TimeoutExpired as exc:
        return (
            124,
            (exc.stdout or b"").decode("utf-8", "replace")
            if isinstance(exc.stdout, bytes)
            else (exc.stdout or ""),
            f"命令执行超时：{exc}",
        )
    except OSError as exc:
        return 126, "", str(exc)
    return proc.returncode, proc.stdout or "", proc.stderr or ""


def _tail(text: str | None, limit: int = 1200) -> str:
    if not text:
        return ""
    cleaned = text.strip()
    if len(cleaned) <= limit:
        return cleaned
    return "…" + cleaned[-limit:]


# ---------------------------------------------------------------------------
# Media model
# ---------------------------------------------------------------------------

TYPE_LABELS = {
    "video": "视频",
    "audio": "音频",
    "subtitle": "字幕",
    "data": "数据",
    "attachment": "附件",
}


@dataclass(frozen=True)
class MediaStream:
    index: int
    raw: dict[str, Any]

    @property
    def codec_type(self) -> str:
        return str(self.raw.get("codec_type") or "unknown")

    @property
    def codec_name(self) -> str:
        return str(self.raw.get("codec_name") or "未知")

    @property
    def codec_long_name(self) -> str:
        return str(self.raw.get("codec_long_name") or "")

    @property
    def profile(self) -> str:
        return str(self.raw.get("profile") or "")

    @property
    def language(self) -> str:
        return str((self.raw.get("tags") or {}).get("language") or "")

    @property
    def title(self) -> str:
        return str((self.raw.get("tags") or {}).get("title") or "")

    @property
    def channels(self) -> int | None:
        return human_int(self.raw.get("channels"))

    @property
    def sample_rate(self) -> int | None:
        return human_int(self.raw.get("sample_rate"))

    @property
    def width(self) -> int | None:
        return human_int(self.raw.get("width"))

    @property
    def height(self) -> int | None:
        return human_int(self.raw.get("height"))

    @property
    def bit_rate(self) -> int | None:
        return human_int(self.raw.get("bit_rate"))

    @property
    def duration(self) -> float | None:
        return human_float(self.raw.get("duration"))

    @property
    def type_label(self) -> str:
        return TYPE_LABELS.get(self.codec_type, self.codec_type)

    @property
    def summary(self) -> str:
        if self.codec_type == "video":
            w, h = self.width, self.height
            resolution = f"{w}×{h}" if w and h else "分辨率未知"
            fps = format_fps(self.raw.get("avg_frame_rate") or self.raw.get("r_frame_rate"))
            pix = self.raw.get("pix_fmt")
            return f"{resolution} · {fps} fps" + (f" · {pix}" if pix else "")
        if self.codec_type == "audio":
            rate = f"{self.sample_rate} Hz" if self.sample_rate else "采样率未知"
            layout = self.raw.get("channel_layout") or (
                f"{self.channels} ch" if self.channels else "声道未知"
            )
            return f"{rate} · {layout}"
        if self.codec_type == "subtitle":
            return "字幕流" + (f" · {self.language}" if self.language else "")
        return self.codec_long_name or self.codec_type


@dataclass
class MediaInfo:
    path: Path
    raw: dict[str, Any]
    probed_at: float = field(default_factory=time.time)

    @property
    def format_info(self) -> dict[str, Any]:
        return self.raw.get("format") or {}

    @property
    def streams(self) -> list[MediaStream]:
        return [
            MediaStream(index=safe_int(item.get("index")), raw=item)
            for item in (self.raw.get("streams") or [])
            if isinstance(item, dict)
        ]

    @property
    def chapters(self) -> list[dict[str, Any]]:
        return [c for c in (self.raw.get("chapters") or []) if isinstance(c, dict)]

    @property
    def format_name(self) -> str:
        return str(self.format_info.get("format_name") or "未知")

    @property
    def format_long_name(self) -> str:
        return str(self.format_info.get("format_long_name") or "")

    @property
    def duration(self) -> float | None:
        value = human_float(self.format_info.get("duration"))
        if value is not None:
            return value
        durations = [s.duration for s in self.streams if s.duration is not None]
        return max(durations) if durations else None

    @property
    def size(self) -> int | None:
        value = human_int(self.format_info.get("size"))
        if value is not None:
            return value
        try:
            return self.path.stat().st_size
        except OSError:
            return None

    @property
    def bit_rate(self) -> int | None:
        return human_int(self.format_info.get("bit_rate"))

    @property
    def tags(self) -> dict[str, Any]:
        return self.format_info.get("tags") or {}

    @property
    def video_streams(self) -> list[MediaStream]:
        return [s for s in self.streams if s.codec_type == "video"]

    @property
    def audio_streams(self) -> list[MediaStream]:
        return [s for s in self.streams if s.codec_type == "audio"]

    @property
    def subtitle_streams(self) -> list[MediaStream]:
        return [s for s in self.streams if s.codec_type == "subtitle"]

    @property
    def stream_counts(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for stream in self.streams:
            counts[stream.codec_type] = counts.get(stream.codec_type, 0) + 1
        return counts

    @property
    def count_text(self) -> str:
        labels = {"video": "视频", "audio": "音频", "subtitle": "字幕"}
        parts = [
            f"{labels.get(kind, kind)} {count}"
            for kind, count in self.stream_counts.items()
            if count
        ]
        return " · ".join(parts) if parts else "无媒体流"

    @property
    def display_title(self) -> str:
        title = self.tags.get("title")
        return str(title) if title else self.path.name

    def short_meta(self) -> str:
        bits = [format_duration(self.duration)]
        if self.video_streams:
            bits.append(self.video_streams[0].codec_name)
        if self.audio_streams:
            bits.append(self.audio_streams[0].codec_name)
        return " · ".join(bits)

    def raw_json(self) -> str:
        return json.dumps(self.raw, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# Capabilities
# ---------------------------------------------------------------------------

CATEGORY_LABELS: dict[str, str] = {
    "encoders": "编码器",
    "decoders": "解码器",
    "filters": "滤镜",
    "formats": "容器格式",
    "protocols": "协议",
    "hwaccels": "硬件加速",
}

CATEGORY_DESCRIPTIONS: dict[str, str] = {
    "encoders": "当前 FFmpeg 可以使用的编码器",
    "decoders": "当前 FFmpeg 可以解码的格式",
    "filters": "视频、音频和字幕滤镜",
    "formats": "可解复用与可复用的容器格式",
    "protocols": "输入与输出协议",
    "hwaccels": "编译进 FFmpeg 的硬件加速接口",
}


@dataclass(frozen=True)
class Capability:
    name: str
    flags: str
    description: str
    group: str
    extra: str = ""


@dataclass
class Capabilities:
    groups: dict[str, list[Capability]]
    errors: dict[str, str] = field(default_factory=dict)
    version: str | None = None
    loaded_at: float = field(default_factory=time.time)

    def items(self, category: str) -> list[Capability]:
        return self.groups.get(category, [])

    def count(self, category: str) -> int:
        return len(self.items(category))

    @property
    def total(self) -> int:
        return sum(len(items) for items in self.groups.values())


_CODEC_FLAG_TYPES = {
    "V": "视频",
    "A": "音频",
    "S": "字幕",
    "D": "数据",
    "T": "附件",
}


def _codec_group(flags: str) -> str:
    for flag, label in _CODEC_FLAG_TYPES.items():
        if flag in flags:
            return label
    return "其他"


def parse_encoders(text: str) -> list[Capability]:
    return _parse_codec_table(text, "编码器")


def parse_decoders(text: str) -> list[Capability]:
    return _parse_codec_table(text, "解码器")


def _parse_codec_table(text: str, kind: str) -> list[Capability]:
    result: list[Capability] = []
    in_table = False
    for line in text.splitlines():
        stripped = line.strip()
        if re.fullmatch(r"-{2,}", stripped):
            in_table = True
            continue
        if not in_table:
            continue
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        flags, name, description = parts
        if len(flags) != 6 or any(ch not in "VASDTF.XB" for ch in flags):
            continue
        extra_bits = []
        if "X" in flags:
            extra_bits.append("实验性")
        if "F" in flags:
            extra_bits.append("帧级多线程")
        if "S" in flags:
            extra_bits.append("切片级多线程")
        result.append(
            Capability(
                name=name,
                flags=flags,
                description=description.strip(),
                group=_codec_group(flags),
                extra=" · ".join([kind, *extra_bits]),
            )
        )
    return result


def parse_filters(text: str) -> list[Capability]:
    result: list[Capability] = []
    pattern = re.compile(r"^\s*([TSC.]{3})\s+(\S+)\s+(\S+)\s+(.*)$")
    for line in text.splitlines():
        if " = " in line:
            continue
        match = pattern.match(line)
        if not match:
            continue
        flags, name, io, description = match.groups()
        io_upper = io.upper()
        if "A" in io_upper and ("V" in io_upper or "N" in io_upper):
            group = "音视频"
        elif "V" in io_upper:
            group = "视频"
        elif "A" in io_upper:
            group = "音频"
        else:
            group = "其他"
        result.append(
            Capability(
                name=name,
                flags=flags,
                description=description.strip(),
                group=group,
                extra=io,
            )
        )
    return result


def parse_formats(text: str) -> list[Capability]:
    result: list[Capability] = []
    in_table = False
    for line in text.splitlines():
        stripped = line.strip()
        if re.fullmatch(r"-{2,}", stripped):
            in_table = True
            continue
        if not in_table:
            continue
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        flags, name, description = parts
        if not all(ch in "DEd" for ch in flags):
            continue
        groups = []
        if "D" in flags:
            groups.append("解复用")
        if "E" in flags:
            groups.append("复用")
        if "d" in flags:
            groups.append("设备")
        result.append(
            Capability(
                name=name,
                flags=flags,
                description=description.strip(),
                group=" + ".join(groups) or "其他",
                extra=" / ".join(groups) or "其他",
            )
        )
    return result


def parse_protocols(text: str) -> list[Capability]:
    directions: dict[str, set[str]] = {}
    section: str | None = None
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.lower().startswith("input"):
            section = "输入"
            continue
        if stripped.lower().startswith("output"):
            section = "输出"
            continue
        if stripped.lower().startswith("supported file protocols"):
            continue
        if section and " " not in stripped:
            directions.setdefault(stripped, set()).add(section)
    result = []
    for name, kinds in sorted(directions.items()):
        joined = " / ".join(sorted(kinds))
        result.append(
            Capability(
                name=name,
                flags="",
                description=f"支持{joined}",
                group="输入 + 输出" if len(kinds) == 2 else joined,
                extra=joined,
            )
        )
    return result


def parse_hwaccels(text: str) -> list[Capability]:
    result: list[Capability] = []
    started = False
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.lower().startswith("hardware acceleration"):
            started = True
            continue
        if not started:
            continue
        result.append(
            Capability(
                name=stripped,
                flags="",
                description="硬件加速方法",
                group="硬件加速",
                extra="hwaccel",
            )
        )
    return result


# ---------------------------------------------------------------------------
# Input path expansion
# ---------------------------------------------------------------------------

MEDIA_EXTENSIONS = {
    ".3g2",
    ".3gp",
    ".aac",
    ".ac3",
    ".aif",
    ".aiff",
    ".alac",
    ".ape",
    ".asf",
    ".avi",
    ".avif",
    ".caf",
    ".dts",
    ".eac3",
    ".f4v",
    ".flac",
    ".flv",
    ".gif",
    ".heic",
    ".m2ts",
    ".m4a",
    ".m4v",
    ".mka",
    ".mkv",
    ".mov",
    ".mp2",
    ".mp3",
    ".mp4",
    ".mpeg",
    ".mpg",
    ".mts",
    ".ogg",
    ".ogm",
    ".ogv",
    ".opus",
    ".rm",
    ".rmvb",
    ".ts",
    ".vob",
    ".wav",
    ".webm",
    ".webp",
    ".wma",
    ".wmv",
}


def expand_media_paths(raw: str, *, max_items: int = 500) -> tuple[list[Path], list[str]]:
    """Expand a user supplied path, glob or directory.

    Returns (paths, skipped_messages). Raises ValueError when nothing matched.
    """
    import glob

    raw = raw.strip().strip('"').strip("'")
    if not raw:
        raise ValueError("请输入文件或目录路径")
    expanded = os.path.expandvars(os.path.expanduser(raw))
    matches: list[Path] = []

    if glob.has_magic(expanded):
        for match in sorted(glob.glob(expanded, recursive=True)):
            matches.append(Path(match))
    else:
        matches.append(Path(expanded))

    if not matches:
        raise ValueError(f"路径不存在：{raw}")

    paths: list[Path] = []
    skipped: list[str] = []
    seen: set[Path] = set()
    for item in matches:
        try:
            resolved = item.expanduser().resolve()
        except OSError:
            resolved = item.absolute()
        if resolved.is_dir():
            children = sorted(
                p
                for p in resolved.iterdir()
                if p.is_file() and p.suffix.lower() in MEDIA_EXTENSIONS
            )
            if not children:
                skipped.append(f"{resolved} 中没有常见媒体文件")
            for child in children:
                _append_unique(child.resolve(), paths, seen)
                if len(paths) >= max_items:
                    skipped.append(f"已达到一次添加 {max_items} 个文件的上限")
                    return paths, skipped
            continue
        if resolved.is_file():
            _append_unique(resolved, paths, seen)
            if len(paths) >= max_items:
                skipped.append(f"已达到一次添加 {max_items} 个文件的上限")
                break
        else:
            skipped.append(f"文件不存在：{resolved}")
    if not paths:
        raise ValueError("；".join(skipped) or "没有找到可添加的文件")
    return paths, skipped


def _append_unique(path: Path, paths: list[Path], seen: set[Path]) -> None:
    if path not in seen:
        seen.add(path)
        paths.append(path)


# ---------------------------------------------------------------------------
# Job plans and execution
# ---------------------------------------------------------------------------


@dataclass
class JobStep:
    label: str
    argv: list[str]
    duration: float | None = None
    output: Path | None = None

    @property
    def command_text(self) -> str:
        return shlex.join(self.argv)


@dataclass
class JobPlan:
    title: str
    steps: list[JobStep]
    note: str = ""

    @property
    def outputs(self) -> list[Path]:
        return [step.output for step in self.steps if step.output is not None]

    @property
    def total_duration(self) -> float | None:
        durations = [step.duration for step in self.steps if step.duration]
        return sum(durations) if durations else None


@dataclass
class JobProgress:
    step_index: int
    step_count: int
    step_label: str
    overall_percent: float | None
    out_time: float | None
    speed: str | None = None
    fps: str | None = None
    bitrate: str | None = None
    frame: str | None = None
    message: str = ""


@dataclass
class JobResult:
    ok: bool
    cancelled: bool = False
    outputs: list[Path] = field(default_factory=list)
    error: str | None = None
    log: str = ""

    @property
    def success(self) -> bool:
        return self.ok and not self.cancelled


ProgressCallback = Callable[[JobProgress], None]


def run_plan(
    plan: JobPlan,
    *,
    on_progress: ProgressCallback | None = None,
    cancel_event: threading.Event | None = None,
) -> JobResult:
    """Execute every step in a plan synchronously.

    This is safe to call from a worker thread.  Progress is reported through
    ``on_progress``; cancellation can be requested by setting ``cancel_event``.
    """
    cancel = cancel_event or threading.Event()
    if not plan.steps:
        return JobResult(False, error="任务没有可执行的步骤")

    logs: list[str] = []
    completed_duration = 0.0
    total_duration = plan.total_duration
    started = time.monotonic()

    def report(
        progress: JobProgress,
    ) -> None:
        if on_progress is not None:
            # A UI callback must never take down the encoding job.
            with contextlib.suppress(Exception):
                on_progress(progress)

    for index, step in enumerate(plan.steps):
        if cancel.is_set():
            return JobResult(
                False,
                cancelled=True,
                outputs=[],
                error="已取消",
                log="\n".join(logs),
            )

        logs.append(f"$ {step.command_text}")
        report(
            JobProgress(
                step_index=index,
                step_count=len(plan.steps),
                step_label=step.label,
                overall_percent=_overall_percent(
                    completed_duration, 0.0, total_duration, index, len(plan.steps)
                ),
                out_time=0.0,
                message="启动 ffmpeg…",
            )
        )

        error_file = tempfile.TemporaryFile()  # noqa: SIM115 (closed in finally)
        try:
            try:
                proc = subprocess.Popen(
                    step.argv,
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.PIPE,
                    stderr=error_file,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    bufsize=1,
                )
            except OSError as exc:
                logs.append(str(exc))
                return JobResult(
                    False,
                    outputs=[],
                    error=f"无法启动 ffmpeg：{exc}",
                    log="\n".join(logs),
                )

            out_queue: Queue[str | None] = Queue()
            reader = threading.Thread(target=_read_stdout, args=(proc, out_queue), daemon=True)
            reader.start()

            current_time = 0.0
            last_report = 0.0
            status = "运行中"
            stats: dict[str, str] = {}
            cancelled = False

            while True:
                if cancel.is_set():
                    cancelled = True
                    _terminate_process(proc)
                    break
                try:
                    line = out_queue.get(timeout=0.25)
                except Empty:
                    # Heartbeat: keeps the UI alive when ffmpeg emits no stats.
                    if cancel.is_set():
                        cancelled = True
                        _terminate_process(proc)
                        break
                    now = time.monotonic()
                    if now - last_report > 0.75:
                        last_report = now
                        report(
                            JobProgress(
                                step_index=index,
                                step_count=len(plan.steps),
                                step_label=step.label,
                                overall_percent=_overall_percent(
                                    completed_duration,
                                    current_time,
                                    total_duration,
                                    index,
                                    len(plan.steps),
                                ),
                                out_time=current_time,
                                speed=stats.get("speed"),
                                fps=stats.get("fps"),
                                bitrate=stats.get("bitrate"),
                                frame=stats.get("frame"),
                                message=status,
                            )
                        )
                    continue
                if line is None:
                    break
                key, _, value = line.strip().partition("=")
                if not key or not _:
                    continue
                if key in {"out_time_us", "out_time_ms"}:
                    raw = human_float(value)
                    if raw is not None:
                        current_time = max(current_time, raw / 1_000_000.0)
                elif key in {"speed", "fps", "bitrate", "frame", "total_size"}:
                    stats[key] = value
                elif key == "progress":
                    status = "完成" if value == "end" else "运行中"
                    if value == "end" and step.duration:
                        current_time = max(current_time, step.duration)

                now = time.monotonic()
                if now - last_report > 0.15 or key == "progress":
                    last_report = now
                    report(
                        JobProgress(
                            step_index=index,
                            step_count=len(plan.steps),
                            step_label=step.label,
                            overall_percent=_overall_percent(
                                completed_duration,
                                current_time,
                                total_duration,
                                index,
                                len(plan.steps),
                            ),
                            out_time=current_time,
                            speed=stats.get("speed"),
                            fps=stats.get("fps"),
                            bitrate=stats.get("bitrate"),
                            frame=stats.get("frame"),
                            message=status,
                        )
                    )

            # Drain the queue briefly so the reader can exit.
            with contextlib.suppress(RuntimeError):
                reader.join(timeout=1.5)

            if cancelled:
                _reap(proc)
                logs.append("已取消")
                return JobResult(
                    False,
                    cancelled=True,
                    outputs=[],
                    error="已取消",
                    log="\n".join(logs),
                )

            try:
                returncode = proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                _terminate_process(proc)
                returncode = -9

            error_file.seek(0)
            stderr = error_file.read().decode("utf-8", "replace")
            if stderr.strip():
                logs.append(stderr.strip())

            if returncode != 0:
                message = _tail(stderr, 1600).strip()
                error = f"{step.label}失败（ffmpeg 退出码 {returncode}）"
                if message:
                    error += f"\n{message}"
                return JobResult(
                    False,
                    outputs=[],
                    error=error,
                    log="\n".join(logs),
                )

            completed_duration += step.duration or 0.0
            report(
                JobProgress(
                    step_index=index,
                    step_count=len(plan.steps),
                    step_label=step.label,
                    overall_percent=100.0
                    if index == len(plan.steps) - 1
                    else _overall_percent(
                        completed_duration,
                        step.duration or 0.0,
                        total_duration,
                        index,
                        len(plan.steps),
                    ),
                    out_time=step.duration,
                    message="完成",
                )
            )
        finally:
            with contextlib.suppress(OSError):
                error_file.close()

    elapsed = time.monotonic() - started
    logs.append(f"全部完成，用时 {elapsed:.1f} 秒")
    return JobResult(
        ok=True,
        outputs=plan.outputs,
        log="\n".join(logs),
    )


def _overall_percent(
    completed: float,
    current: float,
    total: float | None,
    index: int,
    count: int,
) -> float | None:
    if not total or total <= 0:
        return None
    return max(0.0, min(100.0, (completed + current) / total * 100.0))


def _read_stdout(proc: subprocess.Popen[str], out_queue: Queue[str | None]) -> None:
    """Drain ffmpeg's progress stream from a background thread."""
    assert proc.stdout is not None
    try:
        for line in proc.stdout:
            out_queue.put(line)
    finally:
        out_queue.put(None)


def _terminate_process(proc: subprocess.Popen[str]) -> None:
    if proc.poll() is not None:
        return
    try:
        proc.terminate()
    except OSError:
        return
    try:
        proc.wait(timeout=3)
    except subprocess.TimeoutExpired:
        with contextlib.suppress(OSError):
            proc.kill()
        with contextlib.suppress(subprocess.TimeoutExpired):
            proc.wait(timeout=2)


def _reap(proc: subprocess.Popen[str]) -> None:
    with contextlib.suppress(subprocess.TimeoutExpired, OSError):
        proc.wait(timeout=2)


# ---------------------------------------------------------------------------
# Command construction
# ---------------------------------------------------------------------------

CRF_CODECS = {
    "libx264",
    "libx265",
    "libvpx-vp9",
    "libaom-av1",
    "libsvtav1",
    "librav1e",
}
PRESET_CODECS = {"libx264", "libx265", "libsvtav1"}
LOSSLESS_AUDIO_CODECS = {
    "flac",
    "alac",
    "truehd",
    "pcm_s16le",
    "pcm_s24le",
    "pcm_s32le",
    "pcm_f32le",
    "copy",
    "none",
}
VIDEO_EXTENSIONS = {".mp4", ".m4v", ".mov", ".mkv", ".webm", ".avi", ".ts", ".flv"}


def _base_args(ffmpeg: str, overwrite: bool) -> list[str]:
    return [
        ffmpeg,
        "-hide_banner",
        "-nostdin",
        "-loglevel",
        "warning",
        "-progress",
        "pipe:1",
        "-nostats",
        "-y" if overwrite else "-n",
    ]


def _check_output(path: Path, overwrite: bool, input_path: Path | None = None) -> None:
    target = path.expanduser()
    if target.suffix == "":
        raise FFmpegError(f"输出文件需要扩展名：{target}")
    if input_path is not None:
        try:
            if target.resolve() == input_path.expanduser().resolve():
                raise FFmpegError("输出文件不能与输入文件相同")
        except OSError:
            pass
    if target.exists():
        if target.is_dir():
            raise FFmpegError(f"输出路径是一个目录：{target}")
        if not overwrite:
            raise OutputExistsError(f"输出已存在：{target}（勾选“覆盖”后可替换）")
    parent = target.parent
    if parent and not parent.exists():
        parent.mkdir(parents=True, exist_ok=True)


def unique_output_path(
    input_path: Path,
    *,
    suffix: str = "_converted",
    extension: str = ".mp4",
) -> Path:
    base = input_path.with_name(f"{input_path.stem}{suffix}")
    candidate = base.with_suffix(extension)
    if not candidate.exists():
        return candidate
    for number in range(2, 1000):
        candidate = base.with_name(f"{base.name}_{number}").with_suffix(extension)
        if not candidate.exists():
            return candidate
    return base.with_name(f"{base.name}_{int(time.time())}").with_suffix(extension)


def unique_output_dir(input_path: Path, *, suffix: str = "_streams") -> Path:
    candidate = input_path.with_name(f"{input_path.stem}{suffix}")
    if not candidate.exists():
        return candidate
    for number in range(2, 1000):
        option = input_path.with_name(f"{input_path.stem}{suffix}_{number}")
        if not option.exists():
            return option
    return input_path.with_name(f"{input_path.stem}{suffix}_{int(time.time())}")


def build_transcode_plan(
    tools: FFmpegTools,
    info: MediaInfo,
    *,
    output_path: Path,
    video_codec: str = "libx264",
    audio_codec: str = "aac",
    crf: int | None = 23,
    preset: str | None = "medium",
    audio_bitrate: str | None = "192k",
    scale: str | None = None,
    copy_subtitles: bool = False,
    overwrite: bool = False,
) -> JobPlan:
    ffmpeg = tools.require_ffmpeg()
    output_path = output_path.expanduser()
    _check_output(output_path, overwrite, info.path)
    if scale:
        if not re.fullmatch(r"\d+:-?\d+", scale):
            raise FFmpegError("缩放格式应为 WIDTH:HEIGHT，例如 1280:-2")
        if video_codec == "copy":
            raise FFmpegError("复制视频流时不能同时设置缩放")
    if crf is not None and not (0 <= crf <= 63):
        raise FFmpegError("CRF 应在 0–63 之间")

    argv = _base_args(ffmpeg, overwrite)
    argv += ["-i", str(info.path)]

    if video_codec == "none":
        argv.append("-vn")
    else:
        argv += ["-map", "0:v:0?"]
    if audio_codec == "none":
        argv.append("-an")
    else:
        argv += ["-map", "0:a?"]
    if copy_subtitles:
        argv += ["-map", "0:s?"]
    argv += ["-map_metadata", "0"]

    if video_codec != "none":
        argv += ["-c:v", video_codec]
        if video_codec not in {"copy", "none"}:
            if crf is not None and video_codec in CRF_CODECS:
                argv += ["-crf", str(crf)]
            if preset and video_codec in PRESET_CODECS:
                argv += ["-preset", preset]
            if scale:
                argv += ["-vf", f"scale={scale}"]

    if audio_codec != "none":
        argv += ["-c:a", audio_codec]
        if audio_codec not in LOSSLESS_AUDIO_CODECS and audio_bitrate:
            argv += ["-b:a", audio_bitrate]

    if copy_subtitles:
        argv += ["-c:s", "copy"]

    if output_path.suffix.lower() in {".mp4", ".m4v", ".mov"}:
        argv += ["-movflags", "+faststart"]

    argv.append(str(output_path))

    return JobPlan(
        title=f"转码 {info.path.name}",
        steps=[
            JobStep(
                label=f"转码 → {output_path.name}",
                argv=argv,
                duration=info.duration,
                output=output_path,
            )
        ],
        note="使用 FFmpeg 重新编码并生成新文件。",
    )


def build_mux_plan(
    tools: FFmpegTools,
    video_info: MediaInfo,
    audio_info: MediaInfo,
    *,
    output_path: Path,
    encode: bool = False,
    copy_subtitles: bool = True,
    shortest: bool = False,
    overwrite: bool = False,
) -> JobPlan:
    ffmpeg = tools.require_ffmpeg()
    output_path = output_path.expanduser()
    if not video_info.video_streams:
        raise FFmpegError(f"{video_info.path.name} 中没有视频流，不能作为画面源")
    if not audio_info.audio_streams:
        raise FFmpegError(f"{audio_info.path.name} 中没有音频流，不能作为声音源")
    if video_info.path.resolve() == audio_info.path.resolve():
        raise FFmpegError("画面源和声音源不能是同一个文件")
    _check_output(output_path, overwrite, video_info.path)

    argv = _base_args(ffmpeg, overwrite)
    argv += ["-i", str(video_info.path), "-i", str(audio_info.path)]
    argv += ["-map", "0:v:0?", "-map", "1:a:0?"]
    if copy_subtitles:
        argv += ["-map", "0:s?"]
    argv += ["-map_metadata", "0"]

    if encode:
        argv += [
            "-c:v",
            "libx264",
            "-preset",
            "medium",
            "-crf",
            "20",
            "-c:a",
            "aac",
            "-b:a",
            "192k",
        ]
        if copy_subtitles:
            argv += ["-c:s", "copy"]
    else:
        argv += ["-c", "copy"]

    if shortest:
        argv += ["-shortest"]
    if output_path.suffix.lower() in {".mp4", ".m4v", ".mov"}:
        argv += ["-movflags", "+faststart"]
    argv.append(str(output_path))

    duration_values = [value for value in (video_info.duration, audio_info.duration) if value]
    if duration_values:
        duration = min(duration_values) if shortest else max(duration_values)
    else:
        duration = None

    return JobPlan(
        title=f"合流 {video_info.path.name} + {audio_info.path.name}",
        steps=[
            JobStep(
                label=f"合流 → {output_path.name}",
                argv=argv,
                duration=duration,
                output=output_path,
            )
        ],
        note="将画面源与声音源合成为一个文件。",
    )


def _audio_extension(codec: str) -> str:
    mapping = {
        "aac": ".m4a",
        "alac": ".m4a",
        "mp3": ".mp3",
        "opus": ".opus",
        "vorbis": ".ogg",
        "flac": ".flac",
        "ac3": ".ac3",
        "eac3": ".eac3",
        "dts": ".dts",
    }
    if codec in mapping:
        return mapping[codec]
    if codec.startswith("pcm_"):
        return ".wav"
    return ".mka"


def build_split_plan(
    tools: FFmpegTools,
    info: MediaInfo,
    *,
    output_dir: Path,
    mode: str = "type",
    overwrite: bool = False,
) -> JobPlan:
    ffmpeg = tools.require_ffmpeg()
    if mode not in {"type", "stream"}:
        raise FFmpegError(f"未知的分流模式：{mode}")

    output_dir = output_dir.expanduser()
    if output_dir.exists() and not output_dir.is_dir():
        raise FFmpegError(f"输出路径不是目录：{output_dir}")
    output_dir.mkdir(parents=True, exist_ok=True)

    groups: list[tuple[str, list[MediaStream], str]] = []
    if mode == "type":
        for kind, label, extension in (
            ("video", "视频", ".mkv"),
            ("audio", "音频", None),
            ("subtitle", "字幕", ".mkv"),
        ):
            streams = [s for s in info.streams if s.codec_type == kind]
            if not streams:
                continue
            if extension is None:
                extension = _audio_extension(streams[0].codec_name) if len(streams) == 1 else ".mka"
            groups.append((label, streams, extension))
    else:
        for stream in info.streams:
            if stream.codec_type not in {"video", "audio", "subtitle"}:
                continue
            extension = (
                _audio_extension(stream.codec_name) if stream.codec_type == "audio" else ".mkv"
            )
            label = f"{stream.type_label} #{stream.index} ({stream.codec_name})"
            groups.append((label, [stream], extension))

    if not groups:
        raise FFmpegError("该文件没有可提取的视频、音频或字幕流")

    steps: list[JobStep] = []
    stem = info.path.stem
    for label, streams, extension in groups:
        if mode == "type":
            kind = streams[0].codec_type
            suffix = {"video": "video", "audio": "audio", "subtitle": "subtitles"}[kind]
            filename = f"{stem}_{suffix}{extension}"
            map_spec = f"0:{kind[0]}?"
        else:
            stream = streams[0]
            filename = f"{stem}_s{stream.index}_{stream.codec_type}_{stream.codec_name}{extension}"
            map_spec = f"0:{stream.index}"
        filename = _safe_filename(filename)
        output = output_dir / filename
        if output.exists() and not overwrite:
            raise OutputExistsError(f"输出已存在：{output}（勾选“覆盖”后可替换）")
        argv = _base_args(ffmpeg, overwrite)
        argv += [
            "-i",
            str(info.path),
            "-map",
            map_spec,
            "-map_metadata",
            "0",
            "-c",
            "copy",
            str(output),
        ]
        steps.append(
            JobStep(
                label=f"提取 {label} → {filename}",
                argv=argv,
                duration=info.duration,
                output=output,
            )
        )

    return JobPlan(
        title=f"分流 {info.path.name}",
        steps=steps,
        note=f"输出目录：{output_dir}",
    )


def _safe_filename(name: str) -> str:
    cleaned = re.sub(r"[\\/:*?\"<>|\x00-\x1f]", "_", name).strip()
    return cleaned or "output"


def command_preview(plan: JobPlan) -> str:
    """Multiline shell-preview of every command in a plan."""
    return "\n".join(f"$ {step.command_text}" for step in plan.steps)
