"""Textual application for FFmpeg TUI."""

from __future__ import annotations

import asyncio
import contextlib
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

from rich.text import Text
from textual import on
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import Screen
from textual.widgets import Button, Footer, Header, OptionList, Static
from textual.widgets.option_list import Option

from .backend import (
    Capabilities,
    FFmpegError,
    FFmpegTools,
    JobPlan,
    JobResult,
    MediaInfo,
    expand_media_paths,
)
from .render import (
    render_loading,
    render_overview,
    render_probe_error,
    render_welcome,
)
from .screens.add_files import AddFilesScreen
from .screens.analysis import AnalysisScreen
from .screens.capabilities import CapabilitiesScreen
from .screens.confirm import ConfirmScreen, MessageScreen
from .screens.help import HelpScreen
from .screens.job import JobScreen
from .screens.mux import MuxScreen
from .screens.split import SplitScreen
from .screens.transcode import TranscodeScreen


@dataclass
class MediaEntry:
    path: Path
    uid: int
    info: MediaInfo | None = None
    error: str | None = None
    probing: bool = False


class FFmpegTUI(App[None]):
    """Main application."""

    TITLE = "FFmpeg TUI"
    CSS_PATH = "app.tcss"
    ENABLE_COMMAND_PALETTE = False

    def __init__(
        self,
        initial_paths: Iterable[str | Path] | None = None,
        tools: FFmpegTools | None = None,
    ) -> None:
        super().__init__()
        self.tools = tools or FFmpegTools.discover()
        self.initial_paths = [str(path) for path in (initial_paths or [])]

    def on_mount(self) -> None:
        self.theme = "textual-dark"
        self.sub_title = self.tools.status_text
        self.push_screen(MainScreen())


class MainScreen(Screen[None]):
    """File list + media inspector."""

    BINDINGS = [
        Binding("a", "add", "添加"),
        Binding("d", "remove", "移除"),
        Binding("i", "analyze", "分析"),
        Binding("t", "transcode", "转码"),
        Binding("m", "mux", "合流"),
        Binding("s", "split", "分流"),
        Binding("c", "capabilities", "能力"),
        Binding("r", "refresh", "刷新"),
        Binding("question_mark", "help", "帮助", key_display="?"),
        Binding("f1", "help", "帮助", show=False),
        Binding("q", "quit", "退出"),
    ]

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True, icon="▶")
        with Vertical(id="screen-body"):
            yield Static("", id="env-warning", classes="env-warning")
            with Horizontal(id="main"):
                with Vertical(id="files-panel", classes="panel"):
                    with Horizontal(classes="panel-head"):
                        yield Static("文件列表", classes="panel-title")
                        yield Static("0 个文件", id="file-count", classes="panel-meta")
                    yield OptionList(id="file-list")
                    with Horizontal(id="file-actions"):
                        yield Button("添加", id="add", variant="primary")
                        yield Button("移除", id="remove")
                        yield Button("清空", id="clear")

                with Vertical(id="inspector-panel", classes="panel"):
                    with Horizontal(classes="panel-head"):
                        yield Static("媒体详情", classes="panel-title")
                        yield Static("", id="media-badge", classes="panel-meta")
                    with VerticalScroll(id="detail-scroll"):
                        yield Static("", id="detail", classes="report")
                    with Horizontal(id="inspector-actions"):
                        yield Button("分析", id="analyze")
                        yield Button("转码", id="transcode")
                        yield Button("合流", id="mux")
                        yield Button("分流", id="split")
                    yield Static(
                        "Enter 分析 · t 转码 · m 合流 · s 分流 · c 能力",
                        id="key-hint",
                        classes="key-hint",
                    )
        yield Footer()

    def __init__(self) -> None:
        super().__init__()
        self.entries: list[MediaEntry] = []
        self._by_uid: dict[int, MediaEntry] = {}
        self._by_path: dict[str, MediaEntry] = {}
        self._next_uid = 1
        self._selected_path: Path | None = None
        self._probe_queue: asyncio.Queue[Path] = asyncio.Queue()
        self._queued_paths: set[str] = set()
        self._probe_task: asyncio.Task[None] | None = None
        self._cap_task: asyncio.Task[None] | None = None
        self._capabilities: Capabilities | None = None

    @property
    def ff(self) -> FFmpegTUI:
        return self.app  # type: ignore[return-value]

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def on_mount(self) -> None:
        self.ff.sub_title = self.ff.tools.status_text
        self._update_env_banner()
        if not self.ff.tools.available:
            self.notify(
                "未检测到完整的 FFmpeg / ffprobe，转码与分析功能不可用。按 ? 查看帮助。",
                title="环境检查",
                severity="error",
                timeout=12,
            )
        self._probe_task = asyncio.create_task(self._probe_loop())
        self._cap_task = asyncio.create_task(self._load_capabilities())

        initial: list[Path] = []
        for raw in self.ff.initial_paths:
            try:
                paths, skipped = expand_media_paths(raw)
            except (ValueError, OSError) as exc:
                self.notify(str(exc), title="无法加载参数中的文件", severity="warning")
                continue
            initial.extend(paths)
            if skipped:
                self.notify("；".join(skipped), severity="warning", timeout=6)
        if initial:
            self._add_paths(initial, select_first=True, notify=False)
        else:
            self._refresh_file_list()
        self.query_one("#file-list", OptionList).focus()

    async def _load_capabilities(self) -> None:
        if not self.ff.tools.can_run:
            return
        try:
            self._capabilities = await asyncio.to_thread(self.ff.tools.load_capabilities)
        except asyncio.CancelledError:
            raise
        except Exception:
            # The capability page will surface a useful error if needed.
            self._capabilities = None

    def on_unmount(self) -> None:
        for task in (self._probe_task, self._cap_task):
            if task is not None:
                task.cancel()
        self._probe_task = None
        self._cap_task = None

    def _update_env_banner(self) -> None:
        banner = self.query_one("#env-warning", Static)
        tools = self.ff.tools
        if tools.available:
            banner.display = False
            return
        if tools.ffmpeg_path and not tools.ffprobe_path:
            message = "⚠ 已找到 ffmpeg，但缺少 ffprobe，无法分析媒体结构。请安装完整的 FFmpeg。"
        elif tools.ffprobe_path and not tools.ffmpeg_path:
            message = "⚠ 已找到 ffprobe，但缺少 ffmpeg，无法执行转码与合流。"
        else:
            message = (
                "⚠ 未找到 FFmpeg。请安装 FFmpeg 并确保 ffmpeg/ffprobe 在 PATH 中；"
                "按 ? 查看安装提示。"
            )
        banner.update(Text(message, style="bold yellow"))
        banner.display = True

    # ------------------------------------------------------------------
    # File list
    # ------------------------------------------------------------------

    def _entry_for_option(self, option_id: str | None) -> MediaEntry | None:
        if not option_id or not option_id.startswith("f-"):
            return None
        try:
            uid = int(option_id[2:])
        except ValueError:
            return None
        return self._by_uid.get(uid)

    def _option_prompt(self, entry: MediaEntry, index: int) -> Text:
        text = Text()
        text.append(f"{index + 1:>2}  ", style="grey62")
        text.append(entry.path.name, style="bold")
        if entry.probing:
            text.append("   分析中…", style="yellow")
        elif entry.error:
            text.append("   无法读取", style="red")
        elif entry.info:
            text.append("   " + entry.info.short_meta(), style="white")
        else:
            parent = str(entry.path.parent)
            text.append("   " + parent, style="grey62")
        return text

    def _refresh_file_list(self, select_path: Path | None = None) -> None:
        option_list = self.query_one("#file-list", OptionList)
        target = (
            str(select_path)
            if select_path
            else (str(self._selected_path) if self._selected_path else None)
        )
        option_list.clear_options()
        if not self.entries:
            option_list.add_option(
                Option(
                    Text("（文件列表为空，按 a 添加文件）", style="dim"), id="empty", disabled=True
                )
            )
            self._selected_path = None
            self._render_detail()
            self._update_counts()
            self._update_actions()
            return

        for index, entry in enumerate(self.entries):
            option_list.add_option(Option(self._option_prompt(entry, index), id=f"f-{entry.uid}"))
        index = 0
        if target:
            for candidate, entry in enumerate(self.entries):
                if str(entry.path) == target:
                    index = candidate
                    break
        option_list.highlighted = index
        selected = self.entries[index]
        changed = self._selected_path != selected.path
        self._selected_path = selected.path
        self._render_detail(reset_scroll=changed)
        self._update_counts()
        self._update_actions()
        if selected.info is None and selected.error is None:
            self._enqueue_probe(selected.path)

    def _replace_option_prompt(self, entry: MediaEntry) -> None:
        try:
            index = self.entries.index(entry)
            self.query_one("#file-list", OptionList).replace_option_prompt(
                f"f-{entry.uid}", self._option_prompt(entry, index)
            )
        except Exception:
            pass

    def _update_counts(self) -> None:
        self.query_one("#file-count", Static).update(f"{len(self.entries)} 个文件")

    def _add_paths(
        self,
        paths: Iterable[Path],
        *,
        select_first: bool = True,
        notify: bool = True,
    ) -> list[MediaEntry]:
        added: list[MediaEntry] = []
        duplicates = 0
        for path in paths:
            try:
                resolved = Path(path).expanduser().resolve()
            except OSError:
                resolved = Path(path).expanduser().absolute()
            if not resolved.is_file():
                continue
            key = str(resolved)
            if key in self._by_path:
                duplicates += 1
                continue
            entry = MediaEntry(path=resolved, uid=self._next_uid)
            self._next_uid += 1
            self.entries.append(entry)
            self._by_uid[entry.uid] = entry
            self._by_path[key] = entry
            added.append(entry)

        if not added:
            if duplicates and notify:
                self.notify("文件已在列表中", severity="warning")
            return []

        self._refresh_file_list(select_path=added[0].path if select_first else self._selected_path)
        for entry in added:
            self._enqueue_probe(entry.path)
        if notify:
            message = f"已添加 {len(added)} 个文件"
            if duplicates:
                message += f"，跳过 {duplicates} 个重复项"
            self.notify(message, title="文件列表")
        return added

    def _enqueue_probe(self, path: Path) -> None:
        key = str(path)
        entry = self._by_path.get(key)
        if entry is None:
            return
        if entry.info is not None and entry.error is None:
            return
        if key in self._queued_paths:
            return
        self._queued_paths.add(key)
        self._probe_queue.put_nowait(path)

    async def _probe_loop(self) -> None:
        while True:
            path = await self._probe_queue.get()
            key = str(path)
            try:
                entry = self._by_path.get(key)
                if entry is None:
                    continue
                entry.probing = True
                entry.error = None
                self._replace_option_prompt(entry)
                if self._selected_path == entry.path:
                    self._render_detail()
                try:
                    info = await asyncio.to_thread(self.ff.tools.probe, entry.path)
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    entry.info = None
                    entry.error = str(exc)
                else:
                    entry.info = info
                    entry.error = None
                finally:
                    entry.probing = False
                self._replace_option_prompt(entry)
                if self._selected_path == entry.path:
                    self._render_detail()
                self._update_actions()
            finally:
                self._queued_paths.discard(key)
                self._probe_queue.task_done()

    # ------------------------------------------------------------------
    # Inspector
    # ------------------------------------------------------------------

    def _current_entry(self) -> MediaEntry | None:
        if self._selected_path is None:
            return None
        return self._by_path.get(str(self._selected_path))

    def _render_detail(self, *, reset_scroll: bool = False) -> None:
        detail = self.query_one("#detail", Static)
        badge = self.query_one("#media-badge", Static)
        entry = self._current_entry()
        if entry is None:
            detail.update(render_welcome(self.ff.tools))
            badge.update("")
        elif entry.info is not None:
            detail.update(render_overview(entry.info, compact=True))
            badge.update(
                Text(
                    f"{entry.info.count_text}  ·  {entry.info.format_name.split(',')[0]}",
                    style="dim",
                )
            )
        elif entry.error:
            detail.update(render_probe_error(entry.path, entry.error))
            badge.update(Text("读取失败", style="red"))
        else:
            detail.update(render_loading(entry.path))
            badge.update(Text("分析中…", style="yellow"))
        if reset_scroll:
            with contextlib.suppress(Exception):
                self.query_one("#detail-scroll", VerticalScroll).scroll_home(animate=False)

    def _update_actions(self) -> None:
        entry = self._current_entry()
        has_info = entry is not None and entry.info is not None
        for button_id in ("analyze", "transcode", "split"):
            self.query_one(f"#{button_id}", Button).disabled = not has_info
        self.query_one("#remove", Button).disabled = entry is None
        self.query_one("#clear", Button).disabled = not self.entries
        self.query_one("#mux", Button).disabled = not self._mux_possible()

    def _mux_possible(self) -> bool:
        infos = [entry.info for entry in self.entries if entry.info is not None]
        videos = [info for info in infos if info is not None and info.video_streams]
        audios = [info for info in infos if info is not None and info.audio_streams]
        for video in videos:
            for audio in audios:
                if video.path != audio.path:
                    return True
        return False

    def _pending_probes(self) -> bool:
        return any(entry.info is None and entry.error is None for entry in self.entries)

    # ------------------------------------------------------------------
    # Button handlers
    # ------------------------------------------------------------------

    @on(Button.Pressed, "#add")
    def _add_button(self) -> None:
        self.action_add()

    @on(Button.Pressed, "#remove")
    def _remove_button(self) -> None:
        self.action_remove()

    @on(Button.Pressed, "#clear")
    def _clear_button(self) -> None:
        self._clear_all()

    @on(Button.Pressed, "#analyze")
    def _analyze_button(self) -> None:
        self.action_analyze()

    @on(Button.Pressed, "#transcode")
    def _transcode_button(self) -> None:
        self.action_transcode()

    @on(Button.Pressed, "#mux")
    def _mux_button(self) -> None:
        self.action_mux()

    @on(Button.Pressed, "#split")
    def _split_button(self) -> None:
        self.action_split()

    @on(OptionList.OptionHighlighted, "#file-list")
    def _option_highlighted(self, event: OptionList.OptionHighlighted) -> None:
        entry = self._entry_for_option(event.option.id)
        if entry is None or entry.path == self._selected_path:
            return
        self._selected_path = entry.path
        self._render_detail(reset_scroll=True)
        self._update_actions()
        if entry.info is None and entry.error is None:
            self._enqueue_probe(entry.path)

    @on(OptionList.OptionSelected, "#file-list")
    def _option_selected(self, event: OptionList.OptionSelected) -> None:
        entry = self._entry_for_option(event.option.id)
        if entry is None:
            return
        self._selected_path = entry.path
        self.action_analyze()

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------

    def action_add(self) -> None:
        self.app.push_screen(AddFilesScreen(), callback=self._added_from_dialog)

    def _added_from_dialog(self, paths: list[Path] | None) -> None:
        if paths:
            self._add_paths(paths, select_first=True)

    def action_remove(self) -> None:
        entry = self._current_entry()
        if entry is None:
            self.notify("请先选择要移除的文件", severity="warning")
            return
        try:
            index = self.entries.index(entry)
        except ValueError:
            return
        self.entries.remove(entry)
        self._by_uid.pop(entry.uid, None)
        self._by_path.pop(str(entry.path), None)
        next_path = None
        if self.entries:
            next_path = self.entries[min(index, len(self.entries) - 1)].path
        self._selected_path = next_path
        self._refresh_file_list(select_path=next_path)
        self.notify(f"已从列表移除 {entry.path.name}", title="文件列表")

    def _clear_all(self) -> None:
        if not self.entries:
            return
        self.app.push_screen(
            ConfirmScreen(
                "清空文件列表",
                f"确定移除列表中的 {len(self.entries)} 个文件吗？\n这不会删除磁盘上的任何文件。",
                confirm_label="清空",
                danger=True,
            ),
            callback=self._clear_confirmed,
        )

    def _clear_confirmed(self, confirmed: bool | None) -> None:
        if not confirmed:
            return
        self.entries.clear()
        self._by_uid.clear()
        self._by_path.clear()
        self._selected_path = None
        self._refresh_file_list()
        self.notify("文件列表已清空", title="文件列表")

    def action_analyze(self) -> None:
        entry = self._current_entry()
        if entry is None:
            self.notify("请先选择一个文件", severity="warning")
            return
        if entry.info is not None:
            self.app.push_screen(AnalysisScreen(entry.info))
        elif entry.error:
            self.app.push_screen(MessageScreen("无法分析文件", entry.error, style="red"))
        else:
            self.notify("正在分析该文件，请稍候…", severity="warning")

    def action_transcode(self) -> None:
        entry = self._require_ready_entry()
        if entry is None:
            return
        if not self.ff.tools.can_run:
            self._show_missing_tools("ffmpeg")
            return
        self.app.push_screen(
            TranscodeScreen(
                self.ff.tools,
                entry.info,  # type: ignore[arg-type]
                capabilities=self._capabilities,
            ),
            callback=self._plan_ready,
        )

    def action_mux(self) -> None:
        if not self.ff.tools.can_run:
            self._show_missing_tools("ffmpeg")
            return
        if len(self.entries) < 2:
            self.notify("合流至少需要两个文件", severity="warning")
            return
        if self._pending_probes():
            self.notify("正在分析文件，请稍候再试合流", severity="warning")
            return
        sources = [entry.info for entry in self.entries if entry.info is not None]
        if len(sources) < 2:
            self.notify("没有足够的可分析文件用于合流", severity="warning")
            return
        if not self._mux_possible():
            self.notify(
                "需要至少一个含视频流的文件和一个含音频流的不同文件",
                severity="warning",
                timeout=7,
            )
            return
        try:
            screen = MuxScreen(self.ff.tools, sources)  # type: ignore[arg-type]
        except FFmpegError as exc:
            self.notify(str(exc), severity="error")
            return
        self.app.push_screen(screen, callback=self._plan_ready)

    def action_split(self) -> None:
        entry = self._require_ready_entry()
        if entry is None:
            return
        if not self.ff.tools.can_run:
            self._show_missing_tools("ffmpeg")
            return
        self.app.push_screen(
            SplitScreen(self.ff.tools, entry.info),  # type: ignore[arg-type]
            callback=self._plan_ready,
        )

    def action_capabilities(self) -> None:
        if not self.ff.tools.can_run:
            self._show_missing_tools("ffmpeg")
            return
        self.app.push_screen(CapabilitiesScreen(self.ff.tools))

    def action_refresh(self) -> None:
        entry = self._current_entry()
        if entry is None:
            return
        if entry.probing:
            self.notify("该文件正在分析中", severity="warning")
            return
        entry.info = None
        entry.error = None
        self._render_detail()
        self._enqueue_probe(entry.path)
        self.notify(f"正在重新分析 {entry.path.name}", title="分析")

    def action_help(self) -> None:
        self.app.push_screen(HelpScreen(self.ff.tools))

    def action_quit(self) -> None:
        self.app.exit()

    # ------------------------------------------------------------------
    # Job plumbing
    # ------------------------------------------------------------------

    def _require_ready_entry(self) -> MediaEntry | None:
        entry = self._current_entry()
        if entry is None:
            self.notify("请先选择一个文件", severity="warning")
            return None
        if entry.info is None:
            if entry.error:
                self.notify("该文件分析失败，无法执行此操作", severity="error")
            else:
                self.notify("正在分析该文件，请稍候…", severity="warning")
            return None
        return entry

    def _show_missing_tools(self, binary: str) -> None:
        message = (
            f"未找到 {binary}。\n\n"
            "请安装 FFmpeg 并确保 ffmpeg 与 ffprobe 位于 PATH 中：\n"
            "  Ubuntu / Debian   sudo apt install ffmpeg\n"
            "  macOS             brew install ffmpeg\n"
            "  Windows           winget install Gyan.FFmpeg"
        )
        self.app.push_screen(MessageScreen("缺少 FFmpeg 工具", message, style="yellow"))

    def _plan_ready(self, plan: JobPlan | None) -> None:
        if plan is None:
            return
        self.app.push_screen(JobScreen(plan), callback=self._job_finished)

    def _job_finished(self, result: JobResult | None) -> None:
        if result is None:
            return
        if result.cancelled:
            self.notify("任务已取消", title="FFmpeg", severity="warning")
            return
        if not result.ok:
            message = (result.error or "FFmpeg 执行失败").splitlines()[0]
            self.notify(message, title="任务失败", severity="error", timeout=10)
            if result.error and "\n" in result.error:
                self.app.push_screen(MessageScreen("FFmpeg 错误详情", result.error, style="red"))
            return
        if result.outputs:
            self._add_paths(result.outputs, select_first=True, notify=False)
            names = "、".join(path.name for path in result.outputs[:3])
            more = "" if len(result.outputs) <= 3 else f" 等 {len(result.outputs)} 个文件"
            self.notify(
                f"任务完成：{names}{more}",
                title="FFmpeg",
                timeout=8,
            )
        else:
            self.notify("任务完成", title="FFmpeg")
