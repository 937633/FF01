"""FFmpeg TUI — a small terminal interface for FFmpeg."""

from __future__ import annotations

__version__ = "0.1.0"
__all__ = ["__version__"]
