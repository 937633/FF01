"""Command line entry point."""

from __future__ import annotations

import argparse
import json
import sys

from . import __version__
from .backend import (
    FFmpegError,
    FFmpegTools,
    format_bitrate,
    format_duration,
    format_size,
)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ffmpeg-tui",
        description="FFmpeg 的轻量终端界面：媒体分析、转码、合流、分流与能力浏览。",
    )
    parser.add_argument("files", nargs="*", help="启动时加入文件列表的媒体文件或目录")
    parser.add_argument(
        "--ffmpeg-bin",
        default="ffmpeg",
        metavar="PATH",
        help="ffmpeg 可执行文件（默认从 PATH 中查找）",
    )
    parser.add_argument(
        "--ffprobe-bin",
        default="ffprobe",
        metavar="PATH",
        help="ffprobe 可执行文件（默认从 PATH 中查找）",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="检查 FFmpeg / ffprobe 版本后退出",
    )
    parser.add_argument(
        "--probe",
        metavar="FILE",
        help="以文本形式分析一个媒体文件后退出",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="与 --probe 或 --check 搭配，输出 JSON",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    return parser


def _check(tools: FFmpegTools, as_json: bool) -> int:
    payload = {
        "ok": tools.available,
        "ffmpeg": tools.ffmpeg_path,
        "ffprobe": tools.ffprobe_path,
        "ffmpeg_version": tools.ffmpeg_version,
        "ffprobe_version": tools.ffprobe_version,
        "ffmpeg_error": tools.ffmpeg_error,
        "ffprobe_error": tools.ffprobe_error,
    }
    if as_json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(f"FFmpeg TUI {__version__}")
        print(f"ffmpeg : {tools.ffmpeg_path or '未找到'}")
        print(f"         版本 {tools.ffmpeg_version or '未知'}")
        print(f"ffprobe: {tools.ffprobe_path or '未找到'}")
        print(f"         版本 {tools.ffprobe_version or '未知'}")
        if tools.available:
            print("状态   : 就绪")
        else:
            print("状态   : 不可用（需要完整的 ffmpeg 和 ffprobe）")
    return 0 if tools.available else 2


def _probe(tools: FFmpegTools, filename: str, as_json: bool) -> int:
    if not tools.can_probe:
        print(f"错误：{tools.ffprobe_error or '未找到 ffprobe'}", file=sys.stderr)
        return 2
    try:
        info = tools.probe(filename)
    except FFmpegError as exc:
        print(f"错误：{exc}", file=sys.stderr)
        return 1
    if as_json:
        print(info.raw_json())
        return 0

    print(f"文件    : {info.path}")
    print(
        f"容器    : {info.format_name}"
        + (f" ({info.format_long_name})" if info.format_long_name else "")
    )
    print(f"时长    : {format_duration(info.duration, millis=True)}")
    print(f"大小    : {format_size(info.size)}")
    print(f"总码率  : {format_bitrate(info.bit_rate)}")
    print(f"流      : {len(info.streams)}  ({info.count_text})")
    print()
    for stream in info.streams:
        print(
            f"  #{stream.index:<2} {stream.type_label:<4} {stream.codec_name:<16} {stream.summary}"
        )
        details = []
        if stream.language:
            details.append(f"语言 {stream.language}")
        if stream.bit_rate:
            details.append(format_bitrate(stream.bit_rate))
        if details:
            print("       " + " · ".join(details))
    if info.chapters:
        print()
        print(f"章节    : {len(info.chapters)}")
        for index, chapter in enumerate(info.chapters):
            tags = chapter.get("tags") or {}
            print(
                f"  #{index:<2} {format_duration(chapter.get('start_time'), millis=True)}"
                f" → {format_duration(chapter.get('end_time'), millis=True)}"
                f"  {tags.get('title', '')}"
            )
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    tools = FFmpegTools.discover(args.ffmpeg_bin, args.ffprobe_bin)

    if args.check:
        return _check(tools, args.json)
    if args.probe:
        return _probe(tools, args.probe, args.json)

    if not sys.stdout.isatty() or not sys.stdin.isatty():
        print(
            "FFmpeg TUI 需要在交互式终端中运行。\n"
            "可用 --check 检查环境，或用 --probe 文件 进行一次性分析。",
            file=sys.stderr,
        )
        return 2

    from .app import FFmpegTUI

    app = FFmpegTUI(initial_paths=args.files, tools=tools)
    try:
        app.run()
    except KeyboardInterrupt:
        return 130
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
