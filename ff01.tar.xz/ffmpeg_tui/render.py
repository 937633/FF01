"""Rich renderables used by the TUI."""

from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path
from typing import Any

from rich import box
from rich.console import Group, RenderableType
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .backend import (
    FFmpegTools,
    MediaInfo,
    MediaStream,
    format_bitrate,
    format_duration,
    format_fps,
    format_size,
    human_float,
)

STREAM_STYLES = {
    "video": "cyan",
    "audio": "green",
    "subtitle": "yellow",
    "data": "magenta",
    "attachment": "blue",
}

STREAM_LABELS = {
    "video": "视频",
    "audio": "音频",
    "subtitle": "字幕",
    "data": "数据",
    "attachment": "附件",
}


def _stream_style(stream: MediaStream) -> str:
    return STREAM_STYLES.get(stream.codec_type, "white")


def _heading(text: str) -> Text:
    return Text(text, style="bold bright_cyan")


def _muted(text: str) -> Text:
    return Text(text, style="dim")


def _kv_table(rows: Iterable[tuple[str, Any]], *, title: str | None = None) -> Table:
    table = Table(
        title=title,
        box=box.SIMPLE,
        show_header=False,
        expand=True,
        pad_edge=False,
        padding=(0, 1),
    )
    table.add_column("字段", style="dim", no_wrap=True, width=14)
    table.add_column("值", overflow="fold")
    for key, value in rows:
        table.add_row(key, value if isinstance(value, Text) else str(value))
    return table


def render_welcome(tools: FFmpegTools) -> RenderableType:
    title = Text("FFmpeg TUI", style="bold")
    subtitle = Text("一个轻量的 FFmpeg 终端控制台", style="dim")
    lines: list[RenderableType] = [title, subtitle, Text("")]

    status_style = "green" if tools.available else "red"
    lines.append(Text(tools.status_text, style=status_style))
    lines.append(Text(""))

    if not tools.available:
        lines.append(
            Panel(
                Text(
                    "没有找到完整的 FFmpeg / ffprobe。\n\n"
                    "请先安装 FFmpeg：\n"
                    "  Ubuntu / Debian   sudo apt install ffmpeg\n"
                    "  macOS             brew install ffmpeg\n"
                    "  Windows           winget install Gyan.FFmpeg\n\n"
                    "安装后重新启动本程序。",
                    style="yellow",
                ),
                border_style="red",
                title="需要 FFmpeg",
            )
        )

    shortcuts = Table(
        box=box.SIMPLE,
        show_header=False,
        pad_edge=False,
        expand=True,
        title="快捷操作",
        title_style="bold",
    )
    shortcuts.add_column("键", style="bold cyan", width=7, no_wrap=True)
    shortcuts.add_column("操作")
    for key, description in (
        ("a", "添加文件、通配符或目录"),
        ("d", "从列表移除选中项"),
        ("Enter / i", "分析媒体结构"),
        ("t", "转码"),
        ("m", "合流（画面 + 声音）"),
        ("s", "分流 / 提取流"),
        ("c", "查看编解码器、滤镜、格式等能力"),
        ("r", "重新分析当前文件"),
        ("?", "帮助"),
        ("q", "退出"),
    ):
        shortcuts.add_row(key, description)
    lines.append(shortcuts)

    lines.append(
        Text(
            "提示：文件列表只保存本次会话，不会修改原始媒体文件。",
            style="dim",
        )
    )
    return Group(*lines)


def render_loading(path: Path) -> RenderableType:
    return Group(
        Text(path.name, style="bold"),
        Text(str(path), style="dim"),
        Text(""),
        Text("正在读取媒体结构…", style="yellow"),
    )


def render_probe_error(path: Path, error: str) -> RenderableType:
    return Group(
        Text(path.name, style="bold"),
        Text(str(path), style="dim"),
        Text(""),
        Text("无法分析该文件", style="bold red"),
        Text(error),
        Text(""),
        Text("提示：确认文件完整，并且已安装 ffprobe。", style="dim"),
    )


def render_overview(info: MediaInfo, *, compact: bool = False) -> RenderableType:
    parts: list[RenderableType] = []
    parts.append(Text(info.path.name, style="bold"))
    parts.append(Text(str(info.path), style="dim"))

    try:
        stat = info.path.stat()
        file_note = f"文件大小 {format_size(stat.st_size)}"
    except OSError:
        file_note = "文件大小 未知"
    parts.append(Text(file_note, style="dim"))
    parts.append(Text(""))

    meta_rows = [
        (
            "容器",
            info.format_name + (f"  ({info.format_long_name})" if info.format_long_name else ""),
        ),
        ("时长", format_duration(info.duration, millis=True)),
        ("总码率", format_bitrate(info.bit_rate)),
        ("流数量", f"{len(info.streams)}  ({info.count_text})"),
        ("章节", str(len(info.chapters)) if info.chapters else "无"),
    ]
    title = str(info.tags.get("title") or "")
    if title:
        meta_rows.insert(0, ("标题", title))
    parts.append(_kv_table(meta_rows))

    parts.append(_heading("媒体流"))
    if info.streams:
        parts.append(_streams_table(info))
    else:
        parts.append(Text("没有可识别的媒体流", style="yellow"))

    if info.chapters and not compact:
        parts.append(Text(""))
        parts.append(_heading("章节"))
        parts.append(_chapters_table(info))

    if not compact:
        parts.append(Text(""))
        parts.append(Text("按 Enter / i 查看完整结构", style="dim"))
    return Group(*parts)


def _streams_table(info: MediaInfo) -> Table:
    table = Table(
        box=box.SIMPLE_HEAD,
        expand=True,
        pad_edge=False,
        padding=(0, 1),
    )
    table.add_column("#", width=3, justify="right", style="dim")
    table.add_column("类型", width=5, no_wrap=True)
    table.add_column("编码", no_wrap=True)
    table.add_column("参数", overflow="fold")
    table.add_column("语言", width=6, no_wrap=True)
    for stream in info.streams:
        style = _stream_style(stream)
        table.add_row(
            str(stream.index),
            Text(STREAM_LABELS.get(stream.codec_type, stream.codec_type), style=style),
            Text(stream.codec_name, style=style),
            stream.summary,
            stream.language or "—",
        )
    return table


def _chapters_table(info: MediaInfo) -> Table:
    table = Table(box=box.SIMPLE_HEAD, expand=True, pad_edge=False, padding=(0, 1))
    table.add_column("#", width=3, justify="right", style="dim")
    table.add_column("开始", width=10, no_wrap=True)
    table.add_column("结束", width=10, no_wrap=True)
    table.add_column("标题", overflow="fold")
    for index, chapter in enumerate(info.chapters):
        tags = chapter.get("tags") or {}
        table.add_row(
            str(index),
            format_duration(human_float(chapter.get("start_time")), millis=True),
            format_duration(human_float(chapter.get("end_time")), millis=True),
            str(tags.get("title") or "—"),
        )
    return table


def render_streams_detail(info: MediaInfo) -> RenderableType:
    parts: list[RenderableType] = []
    if not info.streams:
        return Text("没有可显示的流。", style="yellow")
    for stream in info.streams:
        style = _stream_style(stream)
        rows: list[tuple[str, Any]] = [
            ("索引", f"#{stream.index}"),
            ("类型", f"{stream.type_label} ({stream.codec_type})"),
            ("编码", stream.codec_name),
        ]
        if stream.codec_long_name:
            rows.append(("编码描述", stream.codec_long_name))
        if stream.profile:
            rows.append(("Profile", stream.profile))
        if stream.raw.get("level") not in (None, 0):
            rows.append(("Level", stream.raw.get("level")))
        if stream.codec_type == "video":
            if stream.width and stream.height:
                rows.append(("分辨率", f"{stream.width} × {stream.height}"))
            if stream.raw.get("pix_fmt"):
                rows.append(("像素格式", stream.raw["pix_fmt"]))
            rows.append(
                (
                    "帧率",
                    (
                        f"{format_fps(stream.raw.get('avg_frame_rate'))} fps "
                        f"(r_frame_rate {format_fps(stream.raw.get('r_frame_rate'))})"
                    ),
                )
            )
            for key, label in (
                ("color_range", "色彩范围"),
                ("color_space", "色彩空间"),
                ("color_transfer", "色彩传递"),
                ("field_order", "扫描顺序"),
            ):
                if stream.raw.get(key):
                    rows.append((label, stream.raw[key]))
        if stream.codec_type == "audio":
            if stream.sample_rate:
                rows.append(("采样率", f"{stream.sample_rate} Hz"))
            if stream.channels:
                rows.append(("声道", str(stream.channels)))
            if stream.raw.get("channel_layout"):
                rows.append(("声道布局", stream.raw["channel_layout"]))
            if stream.raw.get("sample_fmt"):
                rows.append(("采样格式", stream.raw["sample_fmt"]))
        if stream.bit_rate:
            rows.append(("码率", format_bitrate(stream.bit_rate)))
        if stream.duration is not None:
            rows.append(("时长", format_duration(stream.duration, millis=True)))
        if stream.language:
            rows.append(("语言", stream.language))
        if stream.title:
            rows.append(("标题", stream.title))
        if stream.raw.get("time_base"):
            rows.append(("Time base", stream.raw["time_base"]))
        dispositions = [
            key for key, value in (stream.raw.get("disposition") or {}).items() if value
        ]
        if dispositions:
            rows.append(("Disposition", ", ".join(dispositions)))
        tags = stream.raw.get("tags") or {}
        if tags:
            rows.append(("标签", "  ".join(f"{k}={v}" for k, v in tags.items())))
        parts.append(
            Panel(
                _kv_table(rows),
                title=Text(
                    f"#{stream.index}  {stream.type_label}  {stream.codec_name}",
                    style=f"bold {style}",
                ),
                border_style=style,
                padding=(0, 1),
            )
        )
        parts.append(Text(""))
    return Group(*parts)


def render_metadata(info: MediaInfo) -> RenderableType:
    parts: list[RenderableType] = []
    parts.append(_heading("容器元数据"))
    fmt_rows: list[tuple[str, Any]] = [
        ("文件名", info.format_info.get("filename") or info.path.name),
        ("格式名", info.format_name),
        ("完整名称", info.format_long_name or "—"),
        ("时长", format_duration(info.duration, millis=True)),
        ("大小", format_size(info.size)),
        ("码率", format_bitrate(info.bit_rate)),
        ("流数量", str(info.format_info.get("nb_streams") or len(info.streams))),
    ]
    parts.append(_kv_table(fmt_rows))
    if info.tags:
        parts.append(_heading("标签"))
        parts.append(_kv_table(info.tags.items()))

    parts.append(Text(""))
    parts.append(_heading("章节"))
    if info.chapters:
        parts.append(_chapters_table(info))
    else:
        parts.append(Text("没有章节信息", style="dim"))

    stream_tags = [(stream, stream.raw.get("tags") or {}) for stream in info.streams]
    stream_tags = [(stream, tags) for stream, tags in stream_tags if tags]
    if stream_tags:
        parts.append(Text(""))
        parts.append(_heading("流标签"))
        for stream, tags in stream_tags:
            table = _kv_table(tags.items())
            table.title = f"#{stream.index} {stream.type_label} {stream.codec_name}"
            table.title_style = _stream_style(stream)
            parts.append(table)
    return Group(*parts)


def render_stream_summary(info: MediaInfo) -> Text:
    text = Text()
    text.append(format_duration(info.duration), style="cyan")
    text.append("  ·  ")
    text.append(info.count_text)
    return text
