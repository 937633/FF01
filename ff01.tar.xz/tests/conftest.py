from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest

from ffmpeg_tui.backend import FFmpegTools


def _run(argv: list[str]) -> None:
    subprocess.run(argv, check=True, capture_output=True)


@pytest.fixture(scope="session")
def tools() -> FFmpegTools:
    if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
        pytest.skip("FFmpeg / ffprobe are not available")
    found = FFmpegTools.discover()
    if not found.available:
        pytest.skip(f"FFmpeg is not usable: {found.status_text}")
    return found


@pytest.fixture(scope="session")
def media(tmp_path_factory: pytest.TempPathFactory, tools: FFmpegTools) -> dict[str, Path]:
    root = tmp_path_factory.mktemp("media")
    video = root / "sample video.mp4"
    audio = root / "sample audio.mp3"
    _run(
        [
            tools.ffmpeg_path or "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-y",
            "-f",
            "lavfi",
            "-i",
            "testsrc2=size=160x120:rate=15",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=440:sample_rate=44100",
            "-t",
            "2",
            "-c:v",
            "libx264",
            "-preset",
            "ultrafast",
            "-pix_fmt",
            "yuv420p",
            "-c:a",
            "aac",
            "-b:a",
            "96k",
            str(video),
        ]
    )
    _run(
        [
            tools.ffmpeg_path or "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-y",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=660:sample_rate=44100",
            "-t",
            "1.5",
            "-c:a",
            "libmp3lame",
            "-b:a",
            "64k",
            str(audio),
        ]
    )
    return {
        "root": root,
        "video": video,
        "audio": audio,
    }
