from __future__ import annotations

import threading
from pathlib import Path

import pytest

from ffmpeg_tui.backend import (
    FFmpegTools,
    JobPlan,
    JobStep,
    OutputExistsError,
    build_mux_plan,
    build_split_plan,
    build_transcode_plan,
    command_preview,
    expand_media_paths,
    format_bitrate,
    format_duration,
    format_fps,
    format_size,
    parse_decoders,
    parse_encoders,
    parse_filters,
    parse_formats,
    parse_hwaccels,
    parse_protocols,
    run_plan,
    unique_output_path,
)


def test_format_helpers() -> None:
    assert format_duration(3661.25) == "01:01:01"
    assert format_duration(62.5, millis=True) == "01:02.500"
    assert format_duration(None) == "未知"
    assert format_size(1536) == "1.5 KiB"
    assert format_bitrate(1_250_000) == "1.2 Mb/s"
    assert format_fps("30000/1001") == "29.97"
    assert format_fps("25/1") == "25"


def test_capability_parsers() -> None:
    encoders = parse_encoders(
        "Encoders:\n"
        " V..... = Video\n"
        " ------\n"
        " V....D libx264              H.264 / AVC / MPEG-4 AVC (codec h264)\n"
        " A..... aac                  AAC (Advanced Audio Coding)\n"
    )
    assert [item.name for item in encoders] == ["libx264", "aac"]
    assert encoders[0].group == "视频"
    assert encoders[1].group == "音频"

    decoders = parse_decoders(
        "Decoders:\n ------\n V....D h264                 H.264 / AVC / MPEG-4 AVC\n"
    )
    assert decoders[0].name == "h264"

    filters = parse_filters(
        "Filters:\n"
        "  T.. = Timeline support\n"
        " TSC scale             V->V       Scale the input video size.\n"
        " ... asetnsamples      A->A       Set the number of samples per frame.\n"
    )
    assert [item.name for item in filters] == ["scale", "asetnsamples"]
    assert filters[0].extra == "V->V"
    assert filters[1].group == "音频"

    formats = parse_formats(
        "Formats:\n"
        " D.. = Demuxing supported\n"
        " .E. = Muxing supported\n"
        " ---\n"
        " DE  matroska         Matroska\n"
        "  E  mp4              MP4 (MPEG-4 Part 14)\n"
    )
    assert [item.name for item in formats] == ["matroska", "mp4"]
    assert formats[0].group == "解复用 + 复用"

    protocols = parse_protocols(
        "Supported file protocols:\nInput:\n  file\n  http\nOutput:\n  file\n"
    )
    by_name = {item.name: item for item in protocols}
    assert by_name["file"].group == "输入 + 输出"
    assert by_name["http"].group == "输入"

    hwaccels = parse_hwaccels("Hardware acceleration methods:\nvdpau\ncuda\nvaapi\n")
    assert [item.name for item in hwaccels] == ["vdpau", "cuda", "vaapi"]


def test_discover_and_capabilities(tools: FFmpegTools) -> None:
    assert tools.available
    assert tools.ffmpeg_version
    assert tools.ffprobe_version
    assert "FFmpeg" in tools.status_text
    caps = tools.load_capabilities()
    assert len(caps.items("encoders")) > 10
    assert len(caps.items("decoders")) > 10
    assert len(caps.items("filters")) > 10
    assert len(caps.items("formats")) > 10
    assert len(caps.items("protocols")) > 2
    assert not caps.errors


def test_probe_and_metadata(tools: FFmpegTools, media: dict[str, Path]) -> None:
    info = tools.probe(media["video"])
    assert info.path.name == "sample video.mp4"
    assert info.duration and info.duration > 1.5
    assert info.size and info.size > 0
    assert len(info.video_streams) == 1
    assert len(info.audio_streams) == 1
    assert info.video_streams[0].width == 160
    assert info.video_streams[0].height == 120
    assert "视频 1" in info.count_text
    assert "h264" in info.short_meta()
    assert '"streams"' in info.raw_json()


def test_expand_media_paths(media: dict[str, Path]) -> None:
    paths, skipped = expand_media_paths(str(media["root"]))
    assert len(paths) == 2
    assert not skipped

    globbed, _ = expand_media_paths(str(media["root"] / "*.mp4"))
    assert globbed == [media["video"]]

    with pytest.raises(ValueError):
        expand_media_paths(str(media["root"] / "missing-file.mp4"))

    many = unique_output_path(media["video"], suffix="_x", extension=".mp4")
    assert many.name == "sample video_x.mp4"


def test_transcode_plan_and_run(tools: FFmpegTools, media: dict[str, Path], tmp_path: Path) -> None:
    info = tools.probe(media["video"])
    output = tmp_path / "transcoded.mkv"
    plan = build_transcode_plan(
        tools,
        info,
        output_path=output,
        video_codec="libx264",
        audio_codec="aac",
        crf=30,
        preset="ultrafast",
        audio_bitrate="96k",
    )
    assert output.name in command_preview(plan)
    progress: list[float | None] = []
    result = run_plan(plan, on_progress=lambda p: progress.append(p.overall_percent))
    assert result.ok, result.error
    assert result.outputs == [output]
    assert output.exists()
    assert progress
    transcode_info = tools.probe(output)
    assert len(transcode_info.video_streams) == 1
    assert len(transcode_info.audio_streams) == 1

    with pytest.raises(OutputExistsError):
        build_transcode_plan(
            tools,
            info,
            output_path=output,
            video_codec="libx264",
            audio_codec="aac",
        )


def test_mux_plan_and_run(tools: FFmpegTools, media: dict[str, Path], tmp_path: Path) -> None:
    video = tools.probe(media["video"])
    audio = tools.probe(media["audio"])
    output = tmp_path / "muxed.mkv"
    plan = build_mux_plan(
        tools,
        video,
        audio,
        output_path=output,
        encode=False,
        copy_subtitles=False,
        shortest=True,
    )
    result = run_plan(plan)
    assert result.ok, result.error
    merged = tools.probe(output)
    assert len(merged.video_streams) == 1
    assert len(merged.audio_streams) == 1
    assert merged.duration and merged.duration <= 2.1


def test_split_plan_and_run(tools: FFmpegTools, media: dict[str, Path], tmp_path: Path) -> None:
    info = tools.probe(media["video"])
    out_dir = tmp_path / "streams"
    plan = build_split_plan(tools, info, output_dir=out_dir, mode="type")
    assert len(plan.steps) == 2
    result = run_plan(plan)
    assert result.ok, result.error
    assert len(result.outputs) == 2
    for output in result.outputs:
        assert output.exists()
        assert output.parent == out_dir

    with pytest.raises(OutputExistsError):
        build_split_plan(tools, info, output_dir=out_dir, mode="type")


def test_split_each_stream(tools: FFmpegTools, media: dict[str, Path], tmp_path: Path) -> None:
    info = tools.probe(media["video"])
    plan = build_split_plan(tools, info, output_dir=tmp_path / "each", mode="stream")
    assert len(plan.steps) == 2
    assert all("_s" in step.output.name for step in plan.steps if step.output)


def test_run_plan_failure(tools: FFmpegTools, tmp_path: Path) -> None:
    missing = tmp_path / "does-not-exist.mp4"
    plan = JobPlan(
        title="failure",
        steps=[
            JobStep(
                label="读取不存在的文件",
                argv=[
                    tools.ffmpeg_path or "ffmpeg",
                    "-hide_banner",
                    "-i",
                    str(missing),
                    "-f",
                    "null",
                    "-",
                ],
            )
        ],
    )
    result = run_plan(plan)
    assert not result.ok
    assert not result.cancelled
    assert result.error
    assert "读取不存在的文件" in result.error


def test_run_plan_cancel(tools: FFmpegTools, tmp_path: Path) -> None:
    output = tmp_path / "cancel-me.mp4"
    plan = JobPlan(
        title="cancel",
        steps=[
            JobStep(
                label="长任务",
                argv=[
                    tools.ffmpeg_path or "ffmpeg",
                    "-hide_banner",
                    "-loglevel",
                    "error",
                    "-progress",
                    "pipe:1",
                    "-nostats",
                    "-y",
                    "-f",
                    "lavfi",
                    "-i",
                    "testsrc2=size=320x240:rate=30",
                    "-t",
                    "20",
                    "-c:v",
                    "libx264",
                    "-preset",
                    "veryslow",
                    str(output),
                ],
                duration=20,
                output=output,
            )
        ],
    )
    cancel = threading.Event()
    timer = threading.Timer(0.4, cancel.set)
    timer.start()
    try:
        result = run_plan(plan, cancel_event=cancel)
    finally:
        timer.cancel()
    assert result.cancelled
    assert not result.ok
