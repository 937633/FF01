from __future__ import annotations

from pathlib import Path

from ffmpeg_tui.cli import main


def test_cli_check(capsys, tools) -> None:
    code = main(["--check"])
    captured = capsys.readouterr()
    assert code == 0
    assert "版本" in captured.out
    assert "就绪" in captured.out


def test_cli_probe(capsys, media: dict[str, Path]) -> None:
    code = main(["--probe", str(media["video"])])
    captured = capsys.readouterr()
    assert code == 0
    assert "容器" in captured.out
    assert "h264" in captured.out


def test_cli_requires_terminal(capsys) -> None:
    code = main([])
    captured = capsys.readouterr()
    assert code == 2
    assert "交互式终端" in captured.err
