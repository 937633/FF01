from __future__ import annotations

import asyncio
from collections.abc import Callable
from pathlib import Path

import pytest

from ffmpeg_tui.app import FFmpegTUI, MainScreen
from ffmpeg_tui.screens.analysis import AnalysisScreen
from ffmpeg_tui.screens.capabilities import CapabilitiesScreen
from ffmpeg_tui.screens.job import JobScreen
from ffmpeg_tui.screens.mux import MuxScreen
from ffmpeg_tui.screens.split import SplitScreen
from ffmpeg_tui.screens.transcode import TranscodeScreen

pytest.importorskip("textual")
pytest.importorskip("rich")


async def _wait_for(pilot, predicate: Callable[[], bool], *, timeout: float = 8.0) -> None:
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout
    while loop.time() < deadline:
        if predicate():
            return
        await pilot.pause(0.05)
    raise AssertionError("condition was not met before timeout")


def test_app_boots_and_probes(media: dict[str, Path]) -> None:
    async def scenario() -> None:
        app = FFmpegTUI(initial_paths=[media["video"]])
        async with app.run_test(size=(120, 40)) as pilot:
            await _wait_for(
                pilot,
                lambda: (
                    isinstance(app.screen, MainScreen)
                    and bool(app.screen.entries)
                    and app.screen.entries[0].info is not None
                ),
            )
            screen = app.screen
            assert isinstance(screen, MainScreen)
            assert screen.entries[0].path == media["video"]
            assert screen.entries[0].error is None
            option = screen.query_one("#file-list").highlighted_option
            assert option is not None
            assert "sample video.mp4" in str(option.prompt)

    asyncio.run(scenario())


def test_add_and_remove_files(media: dict[str, Path]) -> None:
    async def scenario() -> None:
        app = FFmpegTUI(initial_paths=[media["video"]])
        async with app.run_test(size=(120, 40)) as pilot:
            await _wait_for(
                pilot,
                lambda: (
                    isinstance(app.screen, MainScreen)
                    and app.screen.entries
                    and app.screen.entries[0].info is not None
                ),
            )
            await pilot.press("a")
            await pilot.pause(0.1)
            path_input = app.screen.query_one("#path-input")
            path_input.value = str(media["audio"])
            await pilot.press("enter")
            await _wait_for(
                pilot,
                lambda: isinstance(app.screen, MainScreen) and len(app.screen.entries) == 2,
            )
            assert isinstance(app.screen, MainScreen)
            assert app.screen.entries[1].path == media["audio"]

            await _wait_for(
                pilot,
                lambda: (
                    app.screen.entries[1].info is not None
                    or app.screen.entries[1].error is not None
                ),
            )
            await pilot.press("d")
            await pilot.pause(0.1)
            assert len(app.screen.entries) == 1
            assert app.screen.entries[0].path == media["video"]

    asyncio.run(scenario())


def test_read_only_dialogs(media: dict[str, Path]) -> None:
    async def scenario() -> None:
        app = FFmpegTUI(initial_paths=[media["video"], media["audio"]])
        async with app.run_test(size=(120, 40)) as pilot:
            await _wait_for(
                pilot,
                lambda: (
                    isinstance(app.screen, MainScreen)
                    and len(app.screen.entries) == 2
                    and all(entry.info is not None for entry in app.screen.entries)
                ),
            )
            await pilot.press("i")
            await _wait_for(pilot, lambda: isinstance(app.screen, AnalysisScreen))
            await pilot.press("escape")
            await _wait_for(pilot, lambda: isinstance(app.screen, MainScreen))

            await pilot.press("c")
            await _wait_for(pilot, lambda: isinstance(app.screen, CapabilitiesScreen))
            await _wait_for(
                pilot,
                lambda: app.screen.query_one("#cap-table").row_count > 0,
            )
            await pilot.press("escape")
            await _wait_for(pilot, lambda: isinstance(app.screen, MainScreen))

            await pilot.press("t")
            await _wait_for(pilot, lambda: isinstance(app.screen, TranscodeScreen))
            await pilot.press("escape")
            await _wait_for(pilot, lambda: isinstance(app.screen, MainScreen))

            await pilot.press("m")
            await _wait_for(pilot, lambda: isinstance(app.screen, MuxScreen))
            await pilot.press("escape")
            await _wait_for(pilot, lambda: isinstance(app.screen, MainScreen))

            await pilot.press("s")
            await _wait_for(pilot, lambda: isinstance(app.screen, SplitScreen))
            await pilot.press("escape")
            await _wait_for(pilot, lambda: isinstance(app.screen, MainScreen))

    asyncio.run(scenario())


def test_transcode_job_through_ui(media: dict[str, Path], tmp_path: Path) -> None:
    async def scenario() -> None:
        output = tmp_path / "ui-transcode.mkv"
        app = FFmpegTUI(initial_paths=[media["video"]])
        async with app.run_test(size=(120, 40)) as pilot:
            await _wait_for(
                pilot,
                lambda: (
                    isinstance(app.screen, MainScreen)
                    and app.screen.entries
                    and app.screen.entries[0].info is not None
                ),
            )
            await pilot.press("t")
            await _wait_for(pilot, lambda: isinstance(app.screen, TranscodeScreen))
            app.screen.query_one("#output").value = str(output)
            await pilot.press("ctrl+s")
            await _wait_for(pilot, lambda: isinstance(app.screen, JobScreen))
            job_screen = app.screen
            await _wait_for(pilot, lambda: not job_screen.running, timeout=20)
            assert job_screen.result is not None
            assert job_screen.result.ok, job_screen.result.error
            assert output.exists()
            await pilot.press("escape")
            await _wait_for(pilot, lambda: isinstance(app.screen, MainScreen))
            assert output in [entry.path for entry in app.screen.entries]

    asyncio.run(scenario())


def test_split_job_through_ui(media: dict[str, Path], tmp_path: Path) -> None:
    async def scenario() -> None:
        output_dir = tmp_path / "ui-split"
        app = FFmpegTUI(initial_paths=[media["video"]])
        async with app.run_test(size=(120, 40)) as pilot:
            await _wait_for(
                pilot,
                lambda: (
                    isinstance(app.screen, MainScreen)
                    and app.screen.entries
                    and app.screen.entries[0].info is not None
                ),
            )
            await pilot.press("s")
            await _wait_for(pilot, lambda: isinstance(app.screen, SplitScreen))
            app.screen.query_one("#output-dir").value = str(output_dir)
            await pilot.press("ctrl+s")
            await _wait_for(pilot, lambda: isinstance(app.screen, JobScreen))
            job_screen = app.screen
            await _wait_for(pilot, lambda: not job_screen.running, timeout=20)
            assert job_screen.result is not None
            assert job_screen.result.ok, job_screen.result.error
            assert len(job_screen.result.outputs) >= 2
            assert all(path.exists() for path in job_screen.result.outputs)

    asyncio.run(scenario())


def test_missing_ffmpeg_is_surfaced() -> None:
    from ffmpeg_tui.backend import FFmpegTools

    async def scenario() -> None:
        app = FFmpegTUI(initial_paths=[], tools=FFmpegTools())
        async with app.run_test(size=(100, 30)) as pilot:
            await _wait_for(pilot, lambda: isinstance(app.screen, MainScreen))
            await pilot.pause(0.1)
            banner = app.screen.query_one("#env-warning")
            assert banner.display is True
            assert "未找到 FFmpeg" in str(banner.content)

    asyncio.run(scenario())
