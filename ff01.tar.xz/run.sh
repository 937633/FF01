#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if [ -x ".venv/bin/python" ]; then
    exec .venv/bin/python -m ffmpeg_tui "$@"
fi

if command -v python3 >/dev/null 2>&1 && python3 -c "import textual" >/dev/null 2>&1; then
    exec python3 -m ffmpeg_tui "$@"
fi

cat >&2 <<'EOF'
未找到可用的 Python 依赖（textual）。

请先运行：
  ./setup.sh

或者手动安装：
  python3 -m venv .venv
  .venv/bin/pip install -r requirements.txt
EOF
exit 1
