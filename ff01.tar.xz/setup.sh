#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

PYTHON="${PYTHON:-python3}"
if ! command -v "$PYTHON" >/dev/null 2>&1; then
    echo "错误：未找到 $PYTHON，请先安装 Python 3.10 或更高版本。" >&2
    exit 1
fi

echo "==> 创建虚拟环境 .venv"
"$PYTHON" -m venv .venv
echo "==> 安装依赖"
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
echo
echo "安装完成。运行："
echo "  ./run.sh"
echo
echo "检查 FFmpeg 环境："
echo "  ./run.sh --check"
